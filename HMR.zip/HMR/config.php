<?php

return [
    'mysql_host' => 'localhost',
    'mysql_user' => 'setec',
    'mysql_password' => 'setec@2020',
    'mysql_db' => 'ERP',
    'recordsPerPage' => 10,
    'recordsPerPageOptions' => [ 
        5,10,15,20,30,50,100
    ],
    'roletype' => [
        'admin','user','editor','suadmin'

    ],
        'numLinkNavigator' => 4
]
    
;