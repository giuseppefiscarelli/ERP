<?php
session_start();
require_once '../functions.php';
$action = getParam('action','');
require '../model/test_ride.php';
$params = $_GET;
if(!empty($_SESSION['message'])){
    $message = $_SESSION['message'];
    $alertType = $_SESSION['success'] ? 'success':'danger';
    $iconType = $_SESSION['success'] ? 'check':'exclamation-triangle';
    require 'view/messageDelete.php';
    unset($_SESSION['message'],$_SESSION['success']);

  }
switch ($action){

    case 'delete':
        
        unset($params['action']);
        unset($params['id']);
        
        $queryString = http_build_query($params);

        $id= getParam('id', 0);
        $res = delete($id);
        $message = $res ? 'Record Eliminato' : 'Errore Eliminazione Record!';
        $_SESSION['message'] = $message;
        $_SESSION['success'] = $res;
        header('Location:../test_ride.php?'.$queryString);
    break;

    case 'saveTestride':
        $data = $_POST;
        //var_dump($data);die;
        $firma = $_POST['signCode'];
        $idfirma = $_POST['id_cliente'];
        if((strlen($firma))<3000){
            $res = saveTestride($data); 
            $message = $res ? 'Record Inserito' : 'Errore Inserimento Record!';
            $_SESSION['message'] = $message;
            $_SESSION['success'] = $res; 
            header('Location:../indexhmr.php');
        }else{  
        $firma = substr($firma,strpos($firma,",")+1);
        $firma = base64_decode($firma);
        $path = $_SERVER['DOCUMENT_ROOT'].'/ERP/HMR/docs/testride/sign/';
        
        $res = saveTestride($data); 
        $message = $res ? 'Record Inserito' : 'Errore Inserimento Record!';
        $_SESSION['message'] = $message;
        $_SESSION['success'] = $res;
        //var_dump($res);
        $file = $path.$idfirma.'_sig_pren_tr_'.$res.'.png';
        file_put_contents($file, $firma);
        header('Location:../indexhmr.php');
        }
    break;

    case 'saveTestridefast':
        $data = $_POST;
       
        $firma = $_POST['signCode'];
        $idfirma = $_POST['id_cliente'];
        //var_dump($data);die; 
        if((strlen($firma))<3000){
            $res = saveTestridefast($data); 
            $message = $res ? 'Record Inserito' : 'Errore Inserimento Record!';
            $_SESSION['message'] = $message;
            $_SESSION['success'] = $res; 
            header('Location:../indexhmr.php');
        }else{  
        $firma = substr($firma,strpos($firma,",")+1);
        $firma = base64_decode($firma);
        
        $path = $_SERVER['DOCUMENT_ROOT'].'/ERP/HMR/docs/testride/sign/';
        
        $res = saveTestridefast($data); 
        $message = $res ? 'Record Inserito' : 'Errore Inserimento Record!';
        $_SESSION['message'] = $message;
        $_SESSION['success'] = $res;
        //var_dump($res);
        $file = $path.$idfirma.'_sig_cons_tr_'.$res.'.png';
        file_put_contents($file, $firma);
        header('Location:../indexhmr.php');
        }
    break;
     
    case 'storeTestride':
        $data = $_POST;
        //var_dump($_POST);die;
        $firma = $_POST['signCode'];
        $id = intval(getParam('id',0));
        //var_dump($id);die;
        if((strlen($firma))<3000){
            $res = storeTestride($data,$id); 
            $message = $res ? 'Record Aggiornato' : 'Errore Aggiornamento Record!';

            //var_dump(strlen($firma));
            //die;
            $_SESSION['message'] = $message;
            $_SESSION['success'] = $res;
            header('Location:../test_ridePage.php?id='.$id);    
        }else{  
        $idfirma = $_POST['id_cliente'];

        $firma = substr($firma,strpos($firma,",")+1);
        $firma = base64_decode($firma);
        //var_dump($firma);die;
        $path = $_SERVER['DOCUMENT_ROOT'].'/ERP/HMR/docs/testride/sign/';
        
        //var_dump($id);die;
        $res = storeTestride($data,$id); 
        $message = 'Record Aggiornato, Firma Inserita' ;

        //var_dump($res);
        //die;
        $_SESSION['message'] = $message;
        $_SESSION['success'] = $res;
        $file = $path.$idfirma.'_sig_ricons_tr_'.$id.'.png';
        file_put_contents($file, $firma);
        header('Location:../test_ridePage.php?id='.$id);
        }
    break;

    case 'storeTestridePage':
        $data = $_POST;
        //var_dump($data);die;
        
        $id = intval(getParam('idTr',0));
        //var_dump($id);die;
       
            $res = storeTestridePage($data,$id); 
            $message = $res ? 'Record Aggiornato' : 'Errore Aggiornamento Record!';

            //var_dump(strlen($firma));
            //die;
            $_SESSION['message'] = $message;
            $_SESSION['success'] = $res;
            header('Location:../test_ridePage.php?id='.$id);    
        
        
    break;

    case 'storeTestrideCons':
        $data = $_POST;
        //var_dump($_FILES);die;
        $firma = $_POST['signCode2'];
        $id = intval(getParam('id',0));
        //var_dump($id);die;
        $pathrep = $_SERVER['DOCUMENT_ROOT'].'/ERP/HMR/docs/testride/fotoreport/';
        if($_FILES['freport']||$_FILES['freport2']){
            move_uploaded_file($_FILES['freport']['tmp_name'], $pathrep.$id.'_rep1.jpg');
            move_uploaded_file($_FILES['freport2']['tmp_name'], $pathrep.$id.'_rep2.jpg');
        }
        if((strlen($firma))<3000){
            $res = storeTestrideCons($data,$id); 
            $message = $res ? 'Test Ride Aggiornato, Motoveicolo Consegnato' : 'Errore Aggiornamento Record!';

            //var_dump(strlen($firma));
            //die;
            $_SESSION['message'] = $message;
            $_SESSION['success'] = $res;
            header('Location:../test_ridePage.php?id='.$id);    
        }else{  
        $idfirma = $_POST['id_cliente'];

        $firma = substr($firma,strpos($firma,",")+1);
        $firma = base64_decode($firma);
        //var_dump($firma);die;
        $path = $_SERVER['DOCUMENT_ROOT'].'/ERP/HMR/docs/testride/sign/';
        
        //var_dump($id);die;
        $res = storeTestrideCons($data,$id); 
        $message = $res ? 'Test Ride Aggiornato, Motoveicolo Consegnato, Firma Digitale Inserita': 'Errore Aggiornamento Record!' ;

        //var_dump($res);
        //die;
        $_SESSION['message'] = $message;
        $_SESSION['success'] = $res;
        $file = $path.$idfirma.'_sig_cons_tr_'.$id.'.png';
        file_put_contents($file, $firma);
        header('Location:../test_ridePage.php?id='.$id);
        }
    break;

    case 'storeTestrideConsHome':
        $data = $_POST;
        //var_dump($_POST);die;
        $firma = $_POST['signCode2'];
        $id = intval(getParam('id',0));
        var_dump($id);die;
        if((strlen($firma))<3000){
            $res = storeTestrideCons($data,$id); 
            $message = $res ? 'Test Ride Aggiornato, Motoveicolo Consegnato' : 'Errore Aggiornamento Record!';

            //var_dump(strlen($firma));
            //die;
            $_SESSION['message'] = $message;
            $_SESSION['success'] = $res;
            header('Location:../test_ridePage.php?id='.$id);    
        }else{  
        $idfirma = $_POST['id_cliente'];

        $firma = substr($firma,strpos($firma,",")+1);
        $firma = base64_decode($firma);
        //var_dump($firma);die;
        $path = $_SERVER['DOCUMENT_ROOT'].'/ERP/HMR/docs/testride/sign/';
        
        //var_dump($id);die;
        $res = storeTestrideCons($data,$id); 
        $message = $res ? 'Test Ride Aggiornato, Motoveicolo Consegnato, Firma Digitale Inserita': 'Errore Aggiornamento Record!' ;

        //var_dump($res);
        //die;
        $_SESSION['message'] = $message;
        $_SESSION['success'] = $res;
        $file = $path.$idfirma.'_sig_cons_tr_'.$id.'.png';
        file_put_contents($file, $firma);
        header('Location:../test_ridePage.php?id='.$id);
        }
    break;

    case 'storeTestrideRicons':
        $data = $_POST;
        //var_dump($_POST);die;
        $firma = $_POST['signCode'];
        $km = $data['km_ricons'];
        $targa = $data['id_veicolo'];
        $id = intval(getParam('id',0));
        //var_dump($id);die;
        if((strlen($firma))<3000){
            $res = storeTestrideRicons($data,$id); 
            $message = $res ? 'Test Ride Aggiornato, Motoveicolo Riconsegnato' : 'Errore Aggiornamento TestRide!';
            $res2 = upKM($targa,$km);
            //var_dump(strlen($firma));
            //die;
            $_SESSION['message'] = $message;
            $_SESSION['success'] = $res;
            header('Location:../test_ridePage.php?id='.$id);    
        }else{  
        $idfirma = $_POST['id_cliente'];

        $firma = substr($firma,strpos($firma,",")+1);
        $firma = base64_decode($firma);
        //var_dump($firma);die;
        $path = $_SERVER['DOCUMENT_ROOT'].'/ERP/HMR/docs/testride/sign/';
        
        //var_dump($id);die;
        $res = storeTestridericons($data,$id); 
        $message = $res ? 'Test Ride Aggiornato, Motoveicolo Riconsegnato, Firma Digitale Inserita': 'Errore Aggiornamento TestRide!' ;
        $res2 = upKM($targa,$km);
        //var_dump($res);
        //die;
        $_SESSION['message'] = $message;
        $_SESSION['success'] = $res;
        $file = $path.$idfirma.'_sig_ricons_tr_'.$id.'.png';
        file_put_contents($file, $firma);
        header('Location:../test_ridePage.php?id='.$id);
        }
    break;

    case 'storeTestrideRiconsHome':
        $data = $_POST;
        //var_dump($_POST);die;
        $firma = $_POST['signCode'];
        $km = $data['km_ricons'];
        $targa = $data['id_veicolo'];
        $id = intval(getParam('id',0));
        //var_dump($id);die;
        if((strlen($firma))<3000){
            $res = storeTestrideRicons($data,$id); 
            $message = $res ? 'Test Ride Aggiornato, Motoveicolo Riconsegnato' : 'Errore Aggiornamento TestRide!';
            $res2 = upKM($targa,$km);
            //var_dump(strlen($firma));
            //die;
            $_SESSION['message'] = $message;
            $_SESSION['success'] = $res;
            
            header('Location:../test_ridePage.php?id='.$id);    
        }else{  
        $idfirma = $_POST['id_cliente'];

        $firma = substr($firma,strpos($firma,",")+1);
        $firma = base64_decode($firma);
        //var_dump($firma);die;
        $path = $_SERVER['DOCUMENT_ROOT'].'/ERP/HMR/docs/testride/sign/';
        
        //var_dump($id);die;
        $res = storeTestridericons($data,$id); 
        $message = $res ? 'Test Ride Aggiornato, Motoveicolo Riconsegnato, Firma Digitale Inserita': 'Errore Aggiornamento TestRide!' ;
        $res2 = upKM($targa,$km);    
        //var_dump($res);
        //die;
        $_SESSION['message'] = $message;
        $_SESSION['success'] = $res;
        $file = $path.$idfirma.'_sig_ricons_tr_'.$id.'.png';
        file_put_contents($file, $firma);
        header('Location:../test_ridePage.php?id='.$id);    
    }
    break;
    
    case 'getkm':
        getKM();
        
    break;    
   }