<?php
    require_once 'functions.php';
    require_once 'view/top.php';
?>
<!-- Start wrapper-->
 <div id="wrapper">
  <!--Start sidebar-wrapper-->
<?php
    require_once 'view/sidebar.php';
?>
   <!--End sidebar-wrapper-->
<!--Start topbar header-->
<?php
    require_once 'view/topbar_header.php';
?>    
<!--End topbar header-->

<div class="clearfix"></div>
	
  <div class="content-wrapper">
    <div class="container-fluid">
      
      
      <!--Start Dashboard Content-->
<!--End Dashboard Content-->

<?php
    require_once 'view/footer.php';
?>

</body>
</html>    