<?php
session_start();
require_once '../functions.php';
require_once dirname(__FILE__).'/vendor/autoload.php';
if(!isUserLoggedin()){

  header('Location:../login.php');
  exit;
}


require_once 'headerInclude.php';
?>
<div class="clearfix"></div>
 <!--Start Dashboard Content-->	
  <div class="content-wrapper">
    <div class="container-fluid">

    <?php
    $authPage = $_SESSION['userData']['ambiente'];
    $authThisPage =basename($_SERVER['PHP_SELF']);
    //var_dump($_SERVER);
	  //if(!isUserSuadmin()){
     // if(!checkAuthPage($authPage,$authThisPage)){
       // require_once 'view/403.php' ;
     //   }
     // }
    //  else{
		        require_once 'controller/displayHome.php';
	   // }
	?>
  <!--
<button class="btn btn-primary" onclick="prtPdf(2)">Stampa Modulo Privacy</button>
<script type="text/javascript">
function prtPdf($id) {
	var url = 'report/privacy/privacy2.php?id='+$id;
	window.open(url,"Stampa");
}
</script>
-->


<?php
    require_once 'view/footer.php';

?>
<script type="text/javascript">
var signaturePad2;
var canvas;
var signaturePad;
var canvas2;
$(document).ready(function(){
    $('#calendar').fullCalendar({
    	monthNames: ['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'],
    	monthNamesShort: ['Gen','Feb','Mar','Apr','Mag','Giu','Lug','Ago','Set','Ott','Nov','Dic'],
    	dayNames: ['Domenica','Lunedì','Martedì','Mercoledì','Giovedì','Venerdì','Sabato'],
    	dayNamesShort: ['Dom','Lun','Mar','Mer','gio','Ven','Sab'],
      header: {
        left: 'prev,next today',
        center: 'title',
        right: 'month,agendaWeek,agendaDay'
      },
      
      //defaultDate: '2020-03-12',
      
      navLinks: true, // can click day/week names to navigate views
      selectable: false,
      selectHelper: true,
      
      select: function(start, end) {
        var title = prompt('Event Title:');
        var eventData;
        if (title) {
          eventData = {
            title: title,
            start: start,
            end: end
          };
          //$('#calendar').fullCalendar('renderEvent', eventData, true); // stick? = true
        }
        //$('#calendar').fullCalendar('unselect');
      },
      
      businessHours: false,
      businessHours: [{
        // days of week. an array of zero-based day of week integers (0=Sunday)
         
			    dom: [ 1, 2, 3, 4, 5], // Monday - Thursday
          start: '9:00', // a start time (10am in this example)
			    end: '13:00' // an end time (6pm in this example)
      },
      {
        // days of week. an array of zero-based day of week integers (0=Sunday)
         
			    dom: [ 1, 2, 3, 4, 5], // Monday - Thursday
          start: '14:00', // a start time (10am in this example)
			    end: '18:00' // an end time (6pm in this example)
      }
    
      ],
      
      minTime: '08:00:00', 
      maxTime: '19:00:00',
      editable: false,
      eventLimit: true, // allow "more" link when too many events
      eventClick: function(info) {
      alert('Event: ' + info.event.title);
      alert('Coordinates: ' + info.jsEvent.pageX + ',' + info.jsEvent.pageY);
      alert('View: ' + info.view.type);

      // change the border color just for fun
      info.el.style.borderColor = 'red';
      },
      
      events: [ <?php
                  if($testevent){

                    foreach($testevent as $event){
                      $clievent = getClientecf($event['id_cliente']);
                      $colore = getMotoCol($event['id_veicolo']);
                      //var_dump($colore['colore_tr']);
                      if($clievent){
                      ?>
                                  {
                                      title:'<?= $event['id_veicolo']?> <?=$clievent['cognome'].' '.$clievent['nome']?> ',
                                      start:'<?=$event['data_pren']?>',
                                      color: '<?=$colore['colore_tr']?>'
                                      
                                    

                                  }, 
                  <?  }else{?>
                                  {
                                      title:'<?= $event['id_veicolo']?> Prenotazione Online ',
                                      start :'<?=$event['data_pren']?>',
                                      color: '<?=$colore['colore_tr']?>'

                                  },


                  <?}
                    }
                  }?>
                             
                  
       
      ]
        
    });  

			var wrapper = document.getElementById("signature-pad"),
			clearButton = wrapper.querySelector("[data-action=clear]");
			canvas = wrapper.querySelector("canvas");
			signaturePad = new SignaturePad(canvas);
		  clearButton.addEventListener("click", function (event) {
			signaturePad.clear();
			});
      //signature pad 2:
			var wrapper2 = document.getElementById("signature-pad2"),
			clearButton2 = wrapper2.querySelector("[data-action=clear]");
			canvas2 = wrapper2.querySelector("canvas");
			signaturePad2 = new SignaturePad(canvas2);
			clearButton2.addEventListener("click", function (event) {
			    signaturePad2.clear();
			});
      
	});
	function conferma(){
      //$id = $('#id').val();
			var jsignCode = signaturePad.toDataURL();
 		
 			$("#signCode").val(jsignCode); 
      //var url = 'report/testride/cons.php?id='+$id;
	    //window.open(url,"Stampa");
      $id = $('#id').val();
      setTimeout(function(){ var url = 'report/testride/ricons.php?id='+$id;
	                        window.open(url,"Stampa"); }, 3000);
	  
  };
  function confCons(){
      //$id = $('#id').val();
			var jsignCode = signaturePad2.toDataURL();
 		
 			$("#signCode2").val(jsignCode); 
      //var url = 'report/testride/cons.php?id='+$id;
	    //window.open(url,"Stampa");
      $id = $('#id').val();
      setTimeout(function(){ var url = 'report/testride/cons.php?id='+$id;
	                        window.open(url,"Stampa"); }, 3000);
   };
   function prtPdf() {
    $id = $('#id').val();
	  var url = 'report/testride/cons.php?id='+$id;
	  window.open(url,"Stampa");
    location.reload();
  }
  function prtPdf2() {
    $id = $('#id').val();
	  var url = 'report/testride/ricons.php?id='+$id;
	  window.open(url,"Stampa");
    location.reload();
  }
  function prtPdf3() {
    $id = $('#id').val();
	  var url = 'report/testride/full.php?id='+$id;
	  window.open(url,"Stampa");
    location.reload();
  }
  function btnPdf1() {
    $id = $('#id').val();
	  var url = 'docs/testride/report/'+$id+'_cons.pdf';
	  window.open(url,"Stampa");
  }
  function btnPdf2() {
    $id = $('#id').val();
	  var url = 'docs/testride/report/'+$id+'_ricons.pdf';
	  window.open(url,"Stampa");
  }
  function btnPdf3() {
    $id = $('#id').val();
	  var url = 'docs/testride/report/'+$id+'_full.pdf';
	  window.open(url,"Stampa");
  }
	
				 
			  
	</script>
  

</body>
</html>  