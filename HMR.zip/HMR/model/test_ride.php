<?php



    function getTestride(array $params = []){

        /**
         * @var $conn mysqli
         */

        $conn = $GLOBALS['mysqli'];

        $orderBy = array_key_exists('orderBy', $params) ? $params['orderBy'] : '';
        $orderDir = array_key_exists('orderDir', $params) ? $params['orderDir'] : 'ASC';
        $limit = (int)array_key_exists('recordsPerPage', $params) ? $params['recordsPerPage'] : 10;
        $search2 = (int)array_key_exists('search2', $params) ? $params['search2'] : '';
        $search3 = array_key_exists('search3',$params)?date("Y-m-d H:i:s", strtotime($params['search3'])):date('Y-m-d H:i:s');
        $search4 = array_key_exists('search4',$params)?date("Y-m-d 23:59:59", strtotime($params['search4'])):date('Y-m-d H:i:s');
        $search5 = array_key_exists('search5', $params) ? $params['search5'] :'';
        $search6 = array_key_exists('search6', $params) ? $params['search6'] :'' ;
        //var_dump($params);die;
        $page = (int)array_key_exists('page', $params) ? $params['page'] : 0;
        $start =$limit * ($page -1);
        if($start<0){
        $start = 0;
        }
        $search1 = array_key_exists('search1', $params) ? $params['search1'] : '';
        $search1 = $conn->escape_string($search1);

        
        //$search2 = $conn->escape_string($search2);

    
        
        if($orderDir !=='ASC' && $orderDir !=='DESC'){
        $orderDir = 'ASC';
        }
        $records = [];
            
            $sql ='SELECT * FROM testride';
           if($search1 || $search2 || $search3 || $search4|| $search5|| $search6){
                $sql .=" WHERE";
            }
            if ($search1){
                $sql .=" id '%$search1%' ";
                //$sql .=" OR lisdve LIKE '%$search1%' ";
                if($search2 || $search3|| $search4|| $search5|| $search6){
                    $sql .=" AND ";
                }  
            }
            if($search2){
                $sql .="  stato_test = '$search2'";
                if($search3|| $search4|| $search5|| $search6){
                    $sql .=" AND ";
                }
            }
            if($search3){
                $sql .="  data_pren >= '$search3'";
                 if( $search4|| $search5|| $search6){
                 $sql .=" AND ";
              }
            }
            if($search4){
                $sql .="  data_pren <= '$search4' ";
                if($search5|| $search6){
                  $sql .=" AND ";
              }
            }
             if($search5){
                $sql .="  id_veicolo = '$search5'";
                if($search6){
                  $sql .=" AND ";
              }
            }
            if($search6){
              $sql .="  user_pren ='$search6'";
              
            }
        

            $sql .= " ORDER BY $orderBy $orderDir LIMIT $start, $limit";
            // var_dump($sql);
            $res = $conn->query($sql);
            if($res) {

                while( $row = $res->fetch_assoc()) {
                    $records[] = $row;
                    
                }

            }

        return $records;


    }
    function getUsersList(){

      /**
       * @var $conn mysqli
       */

          $conn = $GLOBALS['mysqli'];

          $amb = $_SESSION['userData']['ambiente'];
          $az = $_SESSION['userData']['azienda'];
          $fl = $_SESSION['userData']['filiale'];
          $records = [];

          

          $sql = "SELECT * FROM users WHERE ambiente = $amb and azienda = '$az' and filiale = '$fl'";
          
          $sql .= " ORDER BY id";
          

          $res = $conn->query($sql);
          if($res) {

            while( $row = $res->fetch_assoc()) {
                $records[] = $row;
                
            }

          }

      return $records;

    }

    function delete(int $id){

        /**
         * @var $conn mysqli
         */
    
          $conn = $GLOBALS['mysqli'];
    
            $sql ='DELETE FROM testride WHERE id = '.$id;
            //var_dump($sql);die;
            $res = $conn->query($sql);
            
            return $res && $conn->affected_rows;
        
        
    }

    function getTest(int $id){

        /**
         * @var $conn mysqli
         */
      
          $conn = $GLOBALS['mysqli'];
            $result=[];
            $sql ='SELECT * FROM testride WHERE id = '.$id;
            //echo $sql;
            $res = $conn->query($sql);
            
            if($res && $res->num_rows){
              $result = $res->fetch_assoc();
              
            }
          return $result;
        
        
    }

    function getTestDay(){

      /**
       * @var $conn mysqli
       */
    
        $conn = $GLOBALS['mysqli'];
        $data = date('Y-m-d');
          $records=[];
          $sql ="SELECT * FROM testride WHERE data_pren like '$data%'";
          //echo $sql;
          $res = $conn->query($sql);
          
          if($res) {

            while( $row = $res->fetch_assoc()) {
                $records[] = $row;
                
            }

        }

      return $records;
      
      
    }

    function getEvent(){

        /**
         * @var $conn mysqli
         */
      
          $conn = $GLOBALS['mysqli'];
            $result=[];
            $sql ='SELECT * FROM testride ';
            //echo $sql;
           
            
            $res = $conn->query($sql);
            if($res) {

                while( $row = $res->fetch_assoc()) {
                    $records[] = $row;
                    
                }

            }

        return $records;
        
        
    }

    function countTestride(array $params = []){
     /**
         * @var $conn mysqli
         */

        $conn = $GLOBALS['mysqli'];

        $orderBy = array_key_exists('orderBy', $params) ? $params['orderBy'] : '';
        $orderDir = array_key_exists('orderDir', $params) ? $params['orderDir'] : 'ASC';
        $limit = (int)array_key_exists('recordsPerPage', $params) ? $params['recordsPerPage'] : 10;
        $search2 = (int)array_key_exists('search2', $params) ? $params['search2'] : '';
        $search3 = array_key_exists('search3',$params)?date("Y-m-d H:i:s", strtotime($params['search3'])):date('Y-m-d H:i:s');
        $search4 = array_key_exists('search4',$params)?date("Y-m-d 23:59:59", strtotime($params['search4'])):date('Y-m-d H:i:s');
        $search5 = array_key_exists('search5', $params) ? $params['search5'] :'';
        $search6 = array_key_exists('search6', $params) ? $params['search6'] :'' ;
        //var_dump($params);die;
        $page = (int)array_key_exists('page', $params) ? $params['page'] : 0;
        $start =$limit * ($page -1);
        if($start<0){
        $start = 0;
        }
        $search1 = array_key_exists('search1', $params) ? $params['search1'] : '';
        $search1 = $conn->escape_string($search1);

        

        
        //$search2 = $conn->escape_string($search2);

       
        
        if($orderDir !=='ASC' && $orderDir !=='DESC'){
          $orderDir = 'ASC';
        }
        $totalList = 0;
            
            $sql ='SELECT count(*) as totalList FROM testride';
            if($search1 || $search2 || $search3 || $search4|| $search5|| $search6){
              $sql .=" WHERE";
          }
          if ($search1){
              $sql .=" id_cliente like %'$search1'% ";
              //$sql .=" OR lisdve LIKE '%$search1%' ";
              if($search2 || $search3|| $search4|| $search5|| $search6){
                  $sql .=" AND ";
              }  
          }
          if($search2){
              $sql .="  stato_test = '$search2'";
              if($search3|| $search4|| $search5|| $search6){
                  $sql .=" AND ";
              }
          }
          if($search3){
              $sql .="  data_pren >= '$search3'";
               if( $search4|| $search5|| $search6){
               $sql .=" AND ";
            }
          }
          if($search4){
              $sql .="  data_pren <= '$search4' ";
              if($search5|| $search6){
                $sql .=" AND ";
            }
          }
           if($search5){
              $sql .="  id_veicolo = '$search5'";
              if($search6){
                $sql .=" AND ";
            }
          }
          if($search6){
            $sql .="  user_pren ='$search6'";
            
          }
             // var_dump($sql);
             $res = $conn->query($sql);
             if($res) {
     
              $row = $res->fetch_assoc();
              $totalList = $row['totalList'];
             }
     
         return $totalList;


    }

    function getCliente($id){

        $conn = $GLOBALS['mysqli'];
            $result=[];
            $sql ="SELECT * FROM anagr_clienti WHERE id = '$id'";
           // echo $sql;
           
                
            $res = $conn->query($sql);
            if($res && $res->num_rows){
                $result = $res->fetch_assoc();
                
              }
         return $result;
    
    }

    function getClientecf($id){

        $conn = $GLOBALS['mysqli'];
            $result=[];
            $sql ="SELECT * FROM anagr_clienti WHERE codfiscale = '$id'";
           // echo $sql;
           
                
            $res = $conn->query($sql);
            if($res && $res->num_rows){
                $result = $res->fetch_assoc();
                
              }
         return $result;
    
    }

    function getMotoinfo($id){

        $conn = $GLOBALS['mysqli'];
            $result=[];
            $sql ="SELECT * FROM veicoli_usati WHERE targa = '$id' AND ab_testride = 'S'";
           // echo $sql;
           
                
            $res = $conn->query($sql);
            if($res && $res->num_rows){
                $result = $res->fetch_assoc();
                
              }
         return $result;
    
    }

    function getComune($id){

        $conn = $GLOBALS['mysqli'];
            $des=0;
            $sql ="SELECT comune as des FROM tab_comuni WHERE codcata = '$id'";
            //echo $sql;
           
                
            $res = $conn->query($sql);
            if($res) {
        
             $row = $res->fetch_assoc();
             $des = $row['des'];
            }
        
           return $des;
    
    }

    function getMoto(){

        /**
         * @var $conn mysqli
         */
      
          $conn = $GLOBALS['mysqli'];
            $result=[];
            $sql ="SELECT * FROM veicoli_usati WHERE ab_testride = 'S' ORDER BY id";
            //echo $sql;
            $res = $conn->query($sql);
            
           
        if($res) {

            while( $row = $res->fetch_assoc()) {
                $records[] = $row;
                
            }

        }

     return $records;
        
        
    }
    function getMotoCol($id){

      /**
       * @var $conn mysqli
       */
    
        $conn = $GLOBALS['mysqli'];
          $result=[];
          $sql ="SELECT * FROM veicoli_usati WHERE ab_testride = 'S' and targa = '$id'";
          //echo $sql;
          $res = $conn->query($sql);
          
         
          if($res && $res->num_rows){
            $result = $res->fetch_assoc();
            
          }
        return $result;
      
      
    }

    function getKM(){

        /**
         * @var $conn mysqli
         */
        $conn = $GLOBALS['mysqli'];
        $data =[];
        $targa = $_REQUEST['targa'];
        $sql ="SELECT * FROM veicoli_usati WHERE targa = '$targa'";
        //print_r($sql);
        //echo $sql;die;
        $result = $conn->query($sql);


        
        if ($result->num_rows > 0) {
        // output data of each row
                while( $row = $result->fetch_assoc()) {
                break; 
                
                }
        }
        


        echo json_encode($row);
    }
    function upKM($targa,$km){

      /**
       * @var $conn mysqli
       */
      $conn = $GLOBALS['mysqli'];
      $result=0;
      
      $sql ="UPDATE veicoli_usati SET km = $km WHERE targa = '$targa'";
      //print_r($sql);
      //echo $sql;die;
      $result = $conn->query($sql);


      
      $res = $conn->query($sql);
            
        if($res ){
              $result =  $conn->affected_rows;
              
        }else{
              $result -1;  
        }
      return $result;
    }

    function saveTestride(array $data){ 

        /**
         * @var $conn mysqli
         */
      
            $conn = $GLOBALS['mysqli'];
                   
            $cod_ambiente = $_SESSION['userData']['ambiente'];
            $cod_azienda = $_SESSION['userData']['azienda'];
            $cod_filiale = $_SESSION['userData']['filiale'];
            $user_ins = $_SESSION['userData']['username'];
            $data_ins = date('Y-m-d H:i:s');
            $user_pren = $_SESSION['userData']['username'];
            $data_pren = $conn->escape_string($data['data_pren']);
            $id_cliente =  $conn->escape_string($data['codfiscale']);
            $id_veicolo =  $conn->escape_string($data['targa']);
            $durata_test =  $conn->escape_string($data['durata_test']);
            $ora_pren =  $conn->escape_string($data['ora_pren']);
            $km_cons =  $conn->escape_string($data['km_cons']);
            $note_pren =$conn->escape_string($data['note_pren']);
            $stato_test = 'P';
            //$durata_test =date("i:s",$conn->escape_string($data['durata_test']));
            //$km_cons =  $conn->escape_string($data['km_cons']);

            
            $result=0;
            $sql ='INSERT INTO testride (id, stato_test, cod_ambiente, cod_azienda, cod_filiale, user_ins, data_ins, user_pren, data_pren, id_cliente, id_veicolo, km_cons, durata_test,note_pren) ';
            
            $sql .=" VALUE ( NULL,'$stato_test','$cod_ambiente', '$cod_azienda', '$cod_filiale', '$user_ins', '$data_ins',  '$user_pren', '$data_pren $ora_pren', '$id_cliente', '$id_veicolo' ,'$km_cons' ,'$durata_test', '$note_pren')";
            
            
            
            
            //print_r($data);
            //echo $sql;die;
            $res = $conn->query($sql);
            
            if($res ){
              $result =  $conn->affected_rows;
              $last_id = mysqli_insert_id($conn);
               //echo "New record created successfully. Last inserted ID is: " . $last_id;
               return $last_id;
            }else{
              $result -1;  
            }
          return $last_id;
        
        
    }

    function saveTestridefast(array $data){ 

      /**
       * @var $conn mysqli
       */
    
          $conn = $GLOBALS['mysqli'];
                 
          $cod_ambiente = $_SESSION['userData']['ambiente'];
          $cod_azienda = $_SESSION['userData']['azienda'];
          $cod_filiale = $_SESSION['userData']['filiale'];
          $user_ins = $_SESSION['userData']['username'];
          $data_ins = date('Y-m-d H:i:s');
          
          $id_cliente =  $conn->escape_string($data['codfiscale']);
          $id_veicolo =  $conn->escape_string($data['targa']);
          $durata_test =  $conn->escape_string($data['durata_test']);
         // $stato_tr = "C";
          $km_cons =  $conn->escape_string($data['km_cons']);
          $note_pren =$conn->escape_string($data['note_pren']);
          //$durata_test =date("i:s",$conn->escape_string($data['durata_test']));
          //$km_cons =  $conn->escape_string($data['km_cons']);

          
          $result=0;
          $sql ='INSERT INTO testride (id, cod_ambiente, cod_azienda, cod_filiale, user_ins, data_ins, user_pren, data_pren, user_cons, data_cons,id_cliente, id_veicolo, km_cons, durata_test,note_pren) ';
          
          $sql .=" VALUE ( NULL, '$cod_ambiente', '$cod_azienda', '$cod_filiale', '$user_ins', '$data_ins',  '$user_ins', '$data_ins', '$user_ins', '$data_ins', '$id_cliente', '$id_veicolo' ,'$km_cons' ,'$durata_test', '$note_pren')";
          
          
          
          
         // print_r($data);
         // echo $sql;die;
          $res = $conn->query($sql);
          
          if($res ){
            $result =  $conn->affected_rows;
            $last_id = mysqli_insert_id($conn);
             //echo "New record created successfully. Last inserted ID is: " . $last_id;
             return $last_id;
          }else{
            $result -1;  
          }
        return $last_id;
      
      
    }

    function storeTestride(array $data,int $id){ 

        /**
         * @var $conn mysqli
         */
      
          $conn = $GLOBALS['mysqli'];
            $data_pre =$conn->escape_string($data['data_pren']);
            $ora_pre = $conn->escape_string($data['ora_pren']);
            $id_cliente = $conn->escape_string($data['codfiscale']);
            $km_ricons = $conn->escape_string($data['km_ricons']?$data['km_ricons']:'');
            if($km_ricons){
            $km_ricons = $conn->escape_string($data['km_ricons']?$data['km_ricons']:'');
            $data_ric = $conn->escape_string($data['data_ricons']?$data['data_ricons']:'');
            $ora_ric = $conn->escape_string($data['ora_ricons']?$data['ora_ricons']:'');
            $data_ricons = $data_ric." ".$ora_ric;
            $user_ricons = $data['km_ricons']?$_SESSION['userData']['username']:'';
            }    
            $data_pren = $data_pre. " ".$ora_pre;
            $user_pren = $data['data_pren']?$_SESSION['userData']['username']:'';

            
      
      
            
            $result=0;
            $sql ='UPDATE testride SET ';
            $sql .= "data_pren = '$data_pren', user_pren = '$user_pren'";
            if($km_ricons){
                $sql .= ",km_ricons = $km_ricons, data_ricons ='$data_ricons', user_ricons='$user_ricons'";
            }
            $sql .=" WHERE id = ".$id;
            //print_r($data);
            //echo $sql;die;
            $res = $conn->query($sql);
            
            if($res ){
              $result =  $conn->affected_rows;
              
            }else{
              $result -1;  
            }
          return $result;
        
        
    }

    function storeTestridePage($data,int $id){ 

      /**
       * @var $conn mysqli
       */
    
        $conn = $GLOBALS['mysqli'];
          $id_cliente =$conn->escape_string($data['id_clientenew']);
          

          
    
    
          
          $result=0;
          $sql ='UPDATE testride SET ';
          $sql .= "id_cliente = '$id_cliente'";
          
          $sql .=" WHERE id = ".$id;
          //print_r($data);
          //echo $sql;die;
          $res = $conn->query($sql);
          
          if($res ){
            $result =  $conn->affected_rows;
            
          }else{
            $result -1;  
          }
        return $result;
      
      
    }
    function storeTestrideCons(array $data,int $id){ 

        /**
         * @var $conn mysqli
         */
      
          $conn = $GLOBALS['mysqli'];
          $report1 =$conn->escape_string($data['report1']);
          $report2 =$conn->escape_string($data['report2']);

            $data_cons = date("Y-m-d H:i");
            $user_cons = $_SESSION['userData']['username'];
            $km_cons = $data['km_cons'];
          //  $stato_tr = "C";
      
      
            
            $result=0;
            $sql ='UPDATE testride SET ';
            $sql .= "data_cons = '$data_cons',user_cons = '$user_cons', km_cons = $km_cons, report1 = '$report1', report2 = '$report2'";
            
            $sql .=" WHERE id = ".$id;
           // print_r($data);
           // echo $sql;die;
            $res = $conn->query($sql);
            
            if($res ){
              $result =  $conn->affected_rows;
              
            }else{
              $result -1;  
            }
          return $result;
        
        
    }

    function storeTestrideRicons(array $data,int $id){ 

      /**
       * @var $conn mysqli
       */
    
        $conn = $GLOBALS['mysqli'];
        $report1 =$conn->escape_string($data['report1']);
        $report2 =$conn->escape_string($data['report2']);
          $data_ricons = date("Y-m-d H:i");
          $user_ricons = $_SESSION['userData']['username'];
          $km_ricons = $data['km_ricons'];
          $data_cons = $data['data_cons'];
          $durata = ((strtotime($data_ricons))- (strtotime($data_cons)))/60;
          //$stato_tr = "D";

          //var_dump($durata);die;
          
          $result=0;
          $sql ='UPDATE testride SET ';
          $sql .= "data_ricons = '$data_ricons',  user_ricons = '$user_ricons', km_ricons = $km_ricons, durata_test = $durata, report1 = '$report1', report2 = '$report2'" ;
          
          $sql .=" WHERE id = ".$id;
          //print_r($data);
          //echo $sql;die;
          $res = $conn->query($sql);
          
          if($res ){
            $result =  $conn->affected_rows;
            
          }else{
            $result -1;  
          }
        return $result;
      
      
    }

    function getPatente($id){

        /**
         * @var $conn mysqli
         */
      
          $conn = $GLOBALS['mysqli'];
            $result=[];
            $sql ="SELECT * FROM patenti WHERE id_cliente = '$id'";
           // echo $sql;
            $res = $conn->query($sql);
            
            if($res && $res->num_rows){
              $result = $res->fetch_assoc();
              
            }
          return $result;
        
        
    }
    
    
