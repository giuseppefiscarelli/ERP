
<?php
session_start();
require_once 'functions.php';


if(!isUserLoggedin()){

  header('Location:login.php');
  exit;
}
require_once 'model/test_ride.php';
$updateUrl = 'test_rideUpdate.php';
$updateCliUrl = 'anagr_cliUpdate.php';
$deleteUrl = 'controller/updateTestride.php';
$updatePatente = 'controller/updateAnagr_cli.php';
require_once 'headerInclude.php';
?>

<div class="clearfix"></div>
 <!--Start Dashboard Content-->	
  <div class="content-wrapper">
    <div class="container-fluid">

    
	   
     

    <?php
    if(!empty($_SESSION['message'])){
      $message = $_SESSION['message'];
      $alertType = $_SESSION['success'] ? 'success':'danger';
      $iconType = $_SESSION['success'] ? 'check':'exclamation-triangle';
      require 'view/messageDelete.php';
      unset($_SESSION['message'],$_SESSION['success']);
    }
    $authPage = $_SESSION['userData']['ambiente'];
    $authThisPage =basename($_SERVER['PHP_SELF']);
	  
	  //if(!checkAuthPage($authPage,$authThisPage)){
		
	//	require_once 'view/403.php' ;
		
	 // }else{	  
        $testevent = getEvent();
        $id = getParam('id',0);
        $action = getParam('action',0);
        $moto = getMoto();
       
            if($id){
                
                $tr = getTest($id);
                
                $cliente = $tr['id_cliente'];
                //$cli= getClientecf($tr['id_cliente']);
                //var_dump($cli);
                if (!$cliente&&$action!=='update'){
                  $cli =[
                    'id' =>'',
                    'cod_ambiente'=>'',
                    'cod_azienda'=>'',
                    'cod_filiale'=>'',
                    'user_ins' =>'',
                    'data_ins'=>'',
                    'user_mod' =>'',
                    'tipo_anagr'=>'',
                    'ragsociale'=>'',
                    'cognome' =>'',
                    'nome' => '',
                    'luogonasc' => '',
                    'datanasc' => '',
                    'provnasc' => '',
                    'nazionalita' => '',
                    'sesso' => '',
                    'codfiscale' => '',
                    'partitaiva' => '',
                    'indirizzores' => '',
                    'luogores' => '',
                    'provres' => '',
                    'capres' => '',
                    'mail1' => '',
                    'mail2' => '',
                    'tel1' => '',
                    'tel2' => '',
                    'mobile1' => '',
                    'mobile2' => '',
                    'fax' => ''
                  ]; 

                  $tr = [
                    'data_pren' => $_COOKIE['data_pren']." ".$_COOKIE['ora_pren'],
                    'km_cons'=>$_COOKIE['km'],
                    'id_veicolo'=>$_COOKIE['id_veicolo'],
                    'durata_test'=>$_COOKIE['durata_test']
                  ];
                 
                  $patente = [
                    'id' => ''
                  ];
                
      
                }if (!$cliente&&$action==='update'){
                  $cli =[
                    'id' =>'',
                    'cod_ambiente'=>'',
                    'cod_azienda'=>'',
                    'cod_filiale'=>'',
                    'user_ins' =>'',
                    'data_ins'=>'',
                    'user_mod' =>'',
                    'tipo_anagr'=>'',
                    'ragsociale'=>'',
                    'cognome' =>'',
                    'nome' => '',
                    'luogonasc' => '',
                    'datanasc' => '',
                    'provnasc' => '',
                    'nazionalita' => '',
                    'sesso' => '',
                    'codfiscale' => '',
                    'partitaiva' => '',
                    'indirizzores' => '',
                    'luogores' => '',
                    'provres' => '',
                    'capres' => '',
                    'mail1' => '',
                    'mail2' => '',
                    'tel1' => '',
                    'tel2' => '',
                    'mobile1' => '',
                    'mobile2' => '',
                    'fax' => ''
                  ];  
                  $patente = [
                    'id' => '',
                    'data_rilascio' => '',
                    'data_scadenza' => '',
                    'ente_rilascio' => '',
                    'numero_patente' => '',
                    'tipo_patente' => ''
  
                  ];  
                }else{   
                  $cli = getClientecf($cliente);
                  //var_dump($cli['codfiscale']);
                  if($cli){
                  $patente = getPatente($cli['codfiscale'],0);
                  if(!$patente){
                      $patente = [
                        'id' => '',
                        'data_rilascio' => '',
                        'data_scadenza' => '',
                        'ente_rilascio' => '',
                        'numero_patente' => '',
                        'tipo_patente' => ''
                      ];
                    }
                  }
                }

                unset($_COOKIE['data_pren'],$_COOKIE['km'],$_COOKIE['id_veicolo'],$_COOKIE['durata_test'],$_COOKIE['ora_pren']);
                $checkveicolo= $tr['id_veicolo']?$tr['id_veicolo']:'';
            }else{
                $cli =[
                    'id' =>'',
                    'cod_ambiente'=>'',
                    'cod_azienda'=>'',
                    'cod_filiale'=>'',
                    'user_ins' =>'', 
                    'data_ins'=>'',
                    'user_mod' =>'',
                    'tipo_anagr'=>'',
                    'ragsociale'=>'',
                    'cognome' =>'',
                    'nome' => '',
                    'luogonasc' => '',
                    'datanasc' => '',
                    'provnasc' => '',
                    'nazionalita' => '',
                    'sesso' => '',
                    'codfiscale' => '',
                    'partitaiva' => '',
                    'indirizzores' => '',
                    'luogores' => '',
                    'provres' => '',
                    'capres' => '',
                    'mail1' => '',
                    'mail2' => '',
                    'tel1' => '',
                    'tel2' => '',
                    'mobile1' => '',
                    'mobile2' => '',
                    'fax' => ''

    
                    
    
                ];
                $tr =[
                  'id' =>'',
                  'id_veicolo' => '',  
                  'km_cons' => 0.0,
                  'durata_test' => 20,
                  'data_pren' => date("Y-m-d h:i"),
                  'ora_pren' => date("h:i") 
                ];
                $patente = [
                  'id' => '',
                  'data_rilascio' => '',
                  'data_scadenza' => '',
                  'ente_rilascio' => '',
                  'numero_patente' => '',
                  'tipo_patente' => ''

                ];
                $cliente = getParam('cliId');
                
                  if ($cliente){
                   
                    $cli = getCliente($cliente);
                    $patente = getPatente($cli['codfiscale']);
                    $tr =[
                      'id' =>'',
                      'id_veicolo' => '',  
                      'km_cons' => 0.0,
                      'durata_test' => 20,
                      'data_pren' => date("Y-m-d h:i"),
                      'ora_pren' => date("h:i") 
                    ];
                    if(!$patente){
                      $patente = [
                        'id' => '',
                        'data_rilascio' => '',
                        'data_scadenza' => '',
                        'ente_rilascio' => '',
                        'numero_patente' => '',
                        'tipo_patente' => ''
                      ];
                    }
                    if(isset($_COOKIE['id_veicolo'])){
                      $tr['data_pren'] =$_COOKIE['data_pren']." ".$_COOKIE['ora_pren'];
                      $tr['km_cons']=$_COOKIE['km'];
                      $tr['id_veicolo']=$_COOKIE['id_veicolo'];
                      $tr['durata_test']=$_COOKIE['durata_test'];
                      //unset($_COOKIE['data_pren'],$_COOKIE['km'],$_COOKIE['id_veicolo'],$_COOKIE['durata_test'],$_COOKIE['ora_pren']);
                    }else{
                      $tr =[
                        'id' =>'',
                        'id_veicolo' => '',  
                        'km_cons' => 0.0,
                        'durata_test' => 20,
                        'data_pren' => date("Y-m-d h:i"),
                        'ora_pren' => date("h:i") 
                      ];
                    } 
                    //var_dump($cli);
                    //var_dump($patente);


                  }
                  $checkanagrcli = $cli['cognome']&&$cli['nome']&&$cli['codfiscale']&&$cli['datanasc']&&$cli['sesso']&&$cli['nazionalita']&&$cli['luogonasc']&&$cli['provnasc'];
                  $checkpat = $patente['id']&&$patente['id_cliente']&&$patente['data_rilascio']&&$patente['data_scadenza']&&$patente['ente_rilascio']&&$patente['tipo_patente'];
                  $checkrescli = $cli['indirizzores']&&$cli['luogores']&&$cli['provres']&&$cli['capres'];
                  $checkpatdoc =  file_exists("docs/CRM/Allegati/patente/".$cli['id']."_patfront.jpg")&&file_exists("docs/CRM/Allegati/patente/".$cli['id']."_patrear.jpg");
                  if(!$tr['id_veicolo']){
                    $checkveicolo= false;
                    //var_dump($checkveicolo);
                  }else{
                    $checkveicolo=$tr['id_veicolo']?$tr['id_veicolo']:$_COOKIE['id_veicolo'];
                  }
                  unset($_COOKIE['data_pren'],$_COOKIE['km'],$_COOKIE['id_veicolo'],$_COOKIE['durata_test'],$_COOKIE['ora_pren']);

            }
            $checkanagrcli = $cli['cognome']&&$cli['nome']&&$cli['codfiscale']&&$cli['datanasc']&&$cli['sesso']&&$cli['nazionalita']&&$cli['luogonasc']&&$cli['provnasc'];
            $checkpat = $patente['id']&&$patente['id_cliente']&&$patente['data_rilascio']&&$patente['data_scadenza']&&$patente['ente_rilascio']&&$patente['tipo_patente'];
            $checkrescli = $cli['indirizzores']&&$cli['luogores']&&$cli['provres']&&$cli['capres'];
            $checkpatdoc =  file_exists("docs/CRM/Allegati/patente/".$cli['id']."_patfront.jpg")&&file_exists("docs/CRM/Allegati/patente/".$cli['id']."_patrear.jpg");
            unset($_COOKIE['data_pren'],$_COOKIE['km'],$_COOKIE['id_veicolo'],$_COOKIE['durata_test'],$_COOKIE['ora_pren']);

            //$checkveicolo= false;
            //var_dump($checkveicolo);                              
             $checksubmit = $checkanagrcli&&$checkpat&&$checkrescli&&$checkpatdoc&&date("Y-m-d") < $patente['data_scadenza'];

            //var_dump($checksubmit);
       
    require_once 'view/formTest_rideUpdate.php';
	   
	 // }	

	?>


    
      
     
<!--End Dashboard Content-->

<?php
    require_once 'view/footer.php';
?>
<script type="text/javascript">
  
</script>


<script type="text/javascript">

  $(function () {
      $('#id_veicolo').on('change select',function(event) {
        

        var targa = $(this).val();
        $('#targa').val(targa);
        $.ajax({
		      url:'script/testride_km.php',
          //  url :'controller/updateTestride.php?action=getKm',
		      type:"POST",
		      data: {targa:targa},
          dataType: 'json',
          success:function(results){
            //for (var motoinfo in results){
              <?php if($checksubmit){
                 if($action==='fastinsert'){?>
              var idCli = $('#id_cliente').val();
              if(idCli > 0){
                $('#submitbutton').removeAttr('disabled');
              };
            <?}else{?>
              $('#submitbutton').removeAttr('disabled');
            <? }
            }else{?>
            $('#submitbutton').removeAttr('disabled');
            <?}?>
              $('#km_cons').val(results['km']).trigger('change');
              
		      	//}     
          }  
		    });
      });
     
      $('#data_pren,#ora_pren,#id_veicolo,#km_cons,#durata_test').change(function() {
          var m_moto = $('#id_veicolo').val();
          var k_moto = $('#km_cons').val();
          var d_pren = $('#data_pren').val();
          var o_pren = $('#ora_pren').val();
          var d_test = $('#durata_test').val(); 
          $('#calendar').fullCalendar('gotoDate',d_pren);
          $('#calendar').fullCalendar('changeView', 'agendaDay');
         
          var date = new Date();
          date.setTime(date.getTime()+(250*1000));
          var expires = "; expires="+date.toGMTString();
          dpren = "data_pren";
          opren = "ora_pren";
          mmoto = "id_veicolo";
          kmoto = "km";
          dtest = "durata_test";
          document.cookie=dpren + "="+d_pren+expires+ ";path=/";
          document.cookie=opren +"="+o_pren+expires+ ";path=/";
          document.cookie=mmoto+"="+m_moto+expires+ ";path=/";
          document.cookie=kmoto+"="+k_moto+expires+ ";path=/";
          document.cookie=dtest+"="+d_test+expires+ ";path=/";
      });
       /** 
      $("#luogonasc").bind("keyup change",function(event) {
        
        var test = $('#luogonasc').val();
        var testb = $('#luogores').val();
        var testc = $('#codfiscale').val();
        
        
       
        $.ajax({
		      url:'script/getComune2.php',
          //  url :'controller/updateTestride.php?action=getKm',
		      type:'post',
		      data: {testb:test},
          dataType: 'json',
          success:function(results){
            //for (var motoinfo in results){
              
				      $('#luogonasc').val(results['comune']);
				 
		      	//}     
          }  
		    })
        $.ajax({
		      url:'script/getComune2.php',
          //  url :'controller/updateTestride.php?action=getKm',
		      type:'post',
		      data: {testb:testb},
          dataType: 'json',
          success:function(results){
            //for (var motoinfo in results){
              
				      $('#luogores').val(results['comune']);
				 
		      	//}     
          }  
		    })
        $.ajax({
		      url:'script/getPatente.php',
          //  url :'controller/updateTestride.php?action=getKm',
		      type:'post',
		      data: {testc:testc},
          dataType: 'json',
          success:function(results){
            //for (var motoinfo in results){
              if(results){
				      $('#numero_patente').val(results['numero_patente']);
              $('#data_rilascio').val(results['data_rilascio']);
              $('#data_scadenza').val(results['data_scadenza']);
              $('#ente_rilascio').val(results['ente_rilascio']);
              $('#tipo_patente').val(results['tipo_patente']);
              $('#id_patente_mod').val(results['id']);
              $('#cf_cliente_mod').val(results['id_cliente']);
              $('#numero_patente_mod').val(results['numero_patente']);
              $('#data_rilascio_mod').val(results['data_rilascio']);
              $('#data_scadenza_mod').val(results['data_scadenza']);
              $('#ente_rilascio_mod').val(results['ente_rilascio']);
              $('#tipo_patente_mod').val(results['tipo_patente']);
              }
				 
		      	//}     
          }  
		    })      
        

      });
*/
      $( "#autocomplete" ).autocomplete({
          source: function( request, response ) {
         
          // Fetch data
          $.ajax({
            url: "script/autoUser.php",
            type: 'post',
            dataType: 'json',
            data: {
            search: request.term
            },
            //success: function(data) {
            //response(data);
            //},
            success: function (data) {
                        if (data) {
                          //var data = [{ label: 'No results found.', val: -1}];
                                  response(data);
                               
                            
                        } else {
                          var d = [{ label: 'No results found.', val: -1}];
                          response(d);
                        }
                    
            }
            
          });
          },
          select: function (event, ui) {
            
            location.href = location.href.split("&",1) + "&cliId=" + ui.item.id;
            var targa = $('#km_cons').val();
             if (targa > 0){ 

                      $('#submitbutton').removeAttr('disabled');
                    };
          return false;
          }

        });
        







      });
    function split(val) {
      return val.split( /,\s*/ );
      };
      function extractLast( term ) {
        return split( term ).pop();
      }; 
      
    
</script>

<script type="text/javascript">
$(document).ready(function() {
  
  
    $('#calendar').fullCalendar({
    	monthNames: ['Gennaio','Febbraio','Marzo','Aprile','Maggio','Giugno','Luglio','Agosto','Settembre','Ottobre','Novembre','Dicembre'],
    	monthNamesShort: ['Gen','Feb','Mar','Apr','Mag','Giu','Lug','Ago','Set','Ott','Nov','Dic'],
    	dayNames: ['Domenica','Lunedì','Martedì','Mercoledì','Giovedì','Venerdì','Sabato'],
    	dayNamesShort: ['Dom','Lun','Mar','Mer','gio','Ven','Sab'],
      header: {
        left: 'prev,next today',
        center: 'title',
        right: 'month,agendaWeek,agendaDay'
      },
      
      //defaultDate: '2020-03-12',
      
      navLinks: true, // can click day/week names to navigate views
      selectable: true,
      selectHelper: true,
      
      select: function(start, end) {
        var title = prompt('Event Title:');
        var eventData;
        if (title) {
          eventData = {
            title: title,
            start: start,
            end: end
          };
          $('#calendar').fullCalendar('renderEvent', eventData, true); // stick? = true
        }
        $('#calendar').fullCalendar('unselect');
      },
      
      businessHours: false,
      businessHours: [{
        // days of week. an array of zero-based day of week integers (0=Sunday)
         
			    dom: [ 1, 2, 3, 4, 5], // Monday - Thursday
          start: '9:00', // a start time (10am in this example)
            end: '13:00' // an end time (6pm in this example)
        },
        {
          // days of week. an array of zero-based day of week integers (0=Sunday)
          
            dom: [ 1, 2, 3, 4, 5], // Monday - Thursday
            start: '14:00', // a start time (10am in this example)
            end: '18:00' // an end time (6pm in this example)
        }
      
      ],
      
      minTime: '08:00:00',
      maxTime: '19:00:00',
      editable: false,
      eventLimit: true, // allow "more" link when too many events
      events: [
        <?php
                  if($testevent){

                    foreach($testevent as $event){
                      $clievent = getClientecf($event['id_cliente']);
                      $colore = getMotoCol($event['id_veicolo']);
                      //var_dump($colore['colore_tr']);
                      if($clievent){
                      ?>
                                  {
                                      title:'<?= $event['id_veicolo']?> <?=$clievent['cognome'].' '.$clievent['nome']?> ',
                                      start:'<?=$event['data_pren']?>',
                                      color: '<?=$colore['colore_tr']?>'
                                      
                                    

                                  }, 
                  <?  }else{?>
                                  {
                                      title:'<?= $event['id_veicolo']?> Prenotazione Online ',
                                      start :'<?=$event['data_pren']?>',
                                      color: '<?=$colore['colore_tr']?>'

                                  },


                  <?}
                    }
                  }?>
      ]
    });
   
  });

  $(function(){
    var cliente = $('#id_cliente').val();
    if (cliente){
      $('#divveicolo').show();
    };
  });
</script>
<script type="text/javascript">
      
 	$(function(){
            CodiceFiscale.utils.birthplaceFields("#provres", "#luogores");
            $("#provres").val("<?=$cli['provres']?$cli['provres']:'RM'?>").change();
            setTimeout(()=>$("#luogores").val("<?=$cli['luogores']?$cli['luogores']:'H501'?>"), 200);
 
            CodiceFiscale.utils.birthplaceFields("#provnasc", "#luogonasc");
            $("#provnasc").val("<?=$cli['provnasc']?$cli['provnasc']:'RM'?>").change();
            setTimeout(()=>$("#luogonasc").val("<?=$cli['luogonasc']?$cli['luogonasc']:'H501'?>"), 200);
            $('#cf').click(function(ev){
                    ev.preventDefault();
                    let cf = new CodiceFiscale({
                        name : $("#nome").val(),
                        surname : $("#cognome").val(),
                        gender : $("#sesso").val(),
                        birthday : $("#datanasc").val(),
                        birthplace : $("#luogonasc").val()
                    });
                    $("#codfiscale").val(cf.toString());

            });

	});
   
      
   
            
        
</script>

<script type="text/javascript">
  var signaturePad;
	
	var canvas;
  $(document).ready(function() {
    var wrapper = document.getElementById("signature-pad"),
		clearButton = wrapper.querySelector("[data-action=clear]");
    canvas = wrapper.querySelector("canvas");
    signaturePad = new SignaturePad(canvas);
		clearButton.addEventListener("click", function (event) {
			    signaturePad.clear();
			});
      //signature pad 2:
		var wrapper2 = document.getElementById("signature-pad2"),
		clearButton2 = wrapper2.querySelector("[data-action=clear]");
		canvas2 = wrapper2.querySelector("canvas");
		signaturePad2 = new SignaturePad(canvas2);
		clearButton2.addEventListener("click", function (event) {
			    signaturePad2.clear();
			});

    });
    function conferma(){
      //$id = $('#id').val();
			var jsignCode = signaturePad.toDataURL();
 		
 			$("#signCode").val(jsignCode); 
      //var url = 'report/testride/cons.php?id='+$id;
	    //window.open(url,"Stampa");
      //$id = $('#id').val();
      //setTimeout(function(){ var url = 'report/testride/ricons.php?id='+$id;
	                       // window.open(url,"Stampa"); }, 3000);
	  
  };
</script>
    </body>
</html>    
