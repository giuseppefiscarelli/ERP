    <?php
    require_once 'model/test_ride.php';
    $testRideDay = getTestDay();
    $testevent = getEvent();
    //var_dump($testevent);
    ?>
    <div class="col-xl-6 col-12">
        <div class="card-body">
            <a style="padding: 40px;font-size: 45px;" type="button" href="test_rideUpdate.php?action=fastinsert" class="btn btn-info btn-lg btn-round btn-block m-1">Nuovo Test</a>
            </div>
    </div>
    <div class="col-xl-6 col-12">
        <div class="card-body">      
            <a style="padding: 40px;font-size: 45px;" type="button" href="test_rideUpdate.php?action=insert" class="btn btn-warning btn-lg btn-round btn-block m-1">Nuova Prenotazione</a>
            
        </div>
    </div>
    <div class="row align-items-center">
        <div class="col-12 col-xl-6">         
            <div class="card rounded-0">
                <div class="card-header text-uppercase">Test Ride Giornalieri</div> 
                <div class="">
                    <div class="table-responsive">
                        <table class="table align-items-center">
                        <?php if($testRideDay){?>
                            <thead>
                                <tr>
                                    <th>n° test<br>Consulente</th>
                                    <th>Veicolo<br>Cliente</th>
                                    <th>Ora consegna<br>Stato</th>
                                    <th style="text-align:center;">Operazioni</th>  
                                </tr>
                            </thead>
                            <tbody>
                                <?
                                      foreach($testRideDay as $tr){
                                          $m = getMotoinfo($tr['id_veicolo']);
                                         
                                          if($tr['id_cliente']){
                                            $cli = getclientecf($tr['id_cliente']);
                                            }else{
                                            $cli =[
                                                'cognome' =>'Prenotazione ',
                                                'nome' => 'telefonica/email',
                                                'codfiscale' => 'Dati cliente non presenti'
                                                
                                            ];

                                            }
                                          if(!$tr['data_cons']){
                                          ?>
                                            

                                
                                    <tr>
                                        <td>id #<?=$tr['id']?><br><?=$tr['user_pren']?></td>
                                        <td><?=$m['marca']?> <?=$m['modello']?><br>Targa <?=$m['targa']?><br>

                                            <?=$cli['cognome']?> <?=$cli['nome']?></td>

                                            <td><?=$tr['data_cons']?date("H:i", strtotime($tr['data_cons'])): date("H:i", strtotime($tr['data_pren']))?><br>
                                            <?php if($tr['data_ricons']){?>
                                            <span class="badge badge-pill badge-success shadow-success m-1"> Riconsegnato</span>
                                            <? }elseif($tr['data_cons']){?>
                                            <span class="badge badge-pill badge-warning shadow-warning m-1"> In Test</span>
                                            <?}elseif(!$tr['data_cons']){?>
                                                <span class="badge badge-pill badge-info shadow-info m-1"> Da consegnare</span>
                                            <?}if(!$tr['id_cliente']){?>
                                                <br><span class="badge badge-pill badge-danger shadow-info m-1"> Dati incompleti</span>         
                                            <?}
                                            ?>
                                            </td>
                                            <td>
                                            <a type="button" class="btn btn-info btn-lg btn-round m-1" data-toggle="modal" data-target="#modal-cons-<?=$tr['id']?>" <?=$tr['id_cliente']?'':'style="display:none;"'?>><i class="fa fa-sign-out" aria-hidden="true" ></i> Consegna</a>
                                            <br><a type="button" class="btn btn-success btn-lg btn-round m-1" href="test_ridePage.php?id=<?=$tr['id']?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Gestione</a>
                                            </td>
                                    </tr>
                                            <div class="modal fade" id="modal-cons-<?=$tr['id']?>" style="display: none;" aria-hidden="true">
                                                <form id="upform" action="controller/updateTestride.php" method="post"> 
                                                <input type="hidden" id="id" name="id" value="<?=$tr['id']?>">
                                                <input type="hidden" id="id_cliente" name="id_cliente" value="<?=$tr['id_cliente']?$cli['id']:''?>">
                                                <input type="hidden" name="action" value ="storeTestrideConsHome">
                                                <input type="hidden" name="signCode2" id="signCode2" value="">  
                                                    <div class="modal-dialog modal-lg modal-dialog-centered">
                                                        <div class="modal-content animated slideInUp">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title">Consegna moto TestRide</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">×</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body" style="display:<?=$tr['id_cliente']&&$patente?'':'none'?>">
                                                                    <div class="col-12  ">
                                                                        <div class="form-group row">
                                                                            <label class="col-sm-4 col-form-label">KM</label>
                                                                            <div class="col-sm-8">
                                                                            <input type="text" id="km" name="km_cons" class="form-control" value="<?=$tr['km_cons']?$tr['km_cons']:0.0?>">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    
                                                                    <?php
                                                                    
                                                                        if(file_exists("docs/testride/sign/".$cli['id']."_sig_cons_tr_".$tr['id'].".png")){

                                                                        
                                                                        ?>
                                                                    <img src="docs/testride/sign/<?=$cli['id']?>_sig_cons_tr_<?=$tr['id']?>.png" >
                                                                        <?php
                                                                    }else{ ?>
                                                                    
                                                                    <div class="col-12">
                                                                        <div class="form-group row"  style="height: 300px;">
                                                                                    
                                                                                        <div id="signature-pad2" class="m-signature-pad" style="width: 450px;height: 200px;">
                                                                                            <div class="m-signature-pad--body">
                                                                                                <canvas width="450" height="200"></canvas>
                                                                                            </div>
                                                                                            
                                                                                            <div class="m-signature-pad--footer">
                                                                                                <div class="description" style="padding-top: 20px;">
                                                                                                </div>
                                                                                                <button type="button" class="button btn btn-primary clear" data-action="clear">Pulisci Campo Firma</button>
                                                                                            </div>
                                                                                        </div> 
                                                                            </div>             
                                                                    </div> 
                                                                    <?php } 
                                                                    ?>       

                                                                    <div class="col-12  ">
                                                                        <div class="form-group row">
                                                                            <label class="col-sm-4 col-form-label">FotoReport</label>
                                                                            <div class="col-sm-8">
                                                                            <input type="file" id="freport" name="freport"  class="" >
                                                                            <textarea rows="3" class="form-control" id="basic-textarea"></textarea>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group row">
                                                                            <label class="col-sm-4 col-form-label">FotoReport2</label>
                                                                            <div class="col-sm-8">
                                                                            <input type="file" id="freport2" name="freport2"  class=""> 
                                                                            <textarea rows="3" class="form-control" id="basic-textarea"></textarea>                                   </div>
                                                                        </div>
                                                                    </div>            
                                                            </div>
                                                            
                                                            
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Chiudi</button>
                                                                <button type="submit" class="btn btn-success"onclick="confCons();"><i class="fa fa-check-square-o"></i> Conferma Consegna</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>                        
                                            </div>
                                <?          }
                                        }  

                                    }else{?>
                                            <tr colspan="4"><td style="text-align: center;">Siamo spiacenti! Oggi non ci sono Test Ride in programma!  </td></tr>
                                    <?}?>  
                            </tbody>            
                        </table>
                    </div>            
                </div>
            </div>
        </div>
        <div class="col-12 col-xl-6" style="<?=$testRideDay?'display:show;':'display:none;'?>">         
            <div class="card rounded-0">
                <div class="card-header text-uppercase">Test Ride in Corso</div>
                <div class="">
                    <div class="table-responsive">
                        <table class="table align-items-center">
                        <?php if($testRideDay){?>
                            <thead>
                                <tr>
                                    <th>n° test<br>Consulente</th>
                                    <th>Veicolo<br>Cliente</th>
                                    <th>Ora consegna<br>Stato</th>
                                    <th style="text-align:center;">Operazioni</th>  
                                </tr>
                            </thead>
                            <tbody>
                                <?
                                      foreach($testRideDay as $tr){
                                          $m = getMotoinfo($tr['id_veicolo']);
                                          $cli = getClientecf($tr['id_cliente']);
                                          if($tr['data_cons']&&!$tr['data_ricons']){
                                          ?>
                                            

                                
                                    <tr>
                                        <td>id #<?=$tr['id']?><br><?=$tr['user_pren']?></td>
                                        <td><?=$m['marca']?> <?=$m['modello']?><br>Targa <?=$m['targa']?><br>
                                            <?=$cli['cognome']?> <?=$cli['nome']?></td>
                                            <td><?=$tr['data_cons']?date("H:i", strtotime($tr['data_cons'])): date("H:i", strtotime($tr['data_pren']))?><br>
                                            <?php if($tr['data_ricons']){?>
                                            <span class="badge badge-pill badge-success shadow-success m-1"> Riconsegnato</span>
                                            <? }elseif($tr['data_cons']){?>
                                            <span class="badge badge-pill badge-warning shadow-warning m-1"> In Test</span>
                                            <?}elseif(!$tr['data_cons']){?>
                                                <span class="badge badge-pill badge-info shadow-info m-1"> Da consegnare</span>
                                            <?}
                                            ?>
                                            </td>
                                            <td>
                                            <a type="button" class="btn btn-info btn-lg btn-round m-1" data-toggle="modal" data-target="#modal-ricons-<?=$tr['id']?>"><i class="fa fa-sign-in" aria-hidden="true"></i> riconsegna</a>
                                            <br><a type="button" class="btn btn-success btn-lg btn-round m-1" href="test_ridePage.php?id=<?=$tr['id']?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Gestione</a>
                                            </td>
                                    </tr>
                                            <div class="modal fade" id="modal-ricons-<?=$tr['id']?>" style="display: none;" aria-hidden="true">
                                                <form id="upform" action="controller/updateTestride.php" method="post"> 
                                                <input type="hidden" id="id" name="id" value="<?=$tr['id']?>">
                                                <input type="hidden" id="id_cliente" name="id_cliente" value="<?=$cli['id']?>">
                                                <input type="hidden" id="id_veicolo" name="id_veicolo" value="<?=$tr['id_veicolo']?>">
                                                <input type="hidden" name="action" value ="storeTestrideRiconsHome">
                                                <input type="hidden" name="signCode" id="signCode" value="">
                                                <input type="hidden" name="data_cons" id="data_cons" value="<?=$tr['data_cons']?>" >
                                                    <div class="modal-dialog modal-dialog-centered">
                                                        <div class="modal-content animated slideInUp">
                                                            <div class="modal-header">
                                                                <h5 class="modal-title">Riconsegna moto TestRide</h5>
                                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">×</span>
                                                                </button>
                                                            </div>
                                                            <div class="modal-body">
                                                                    <div class="col-12  ">
                                                                        <div class="form-group row">
                                                                            <label class="col-sm-4 col-form-label">KM</label>
                                                                            <div class="col-sm-8">
                                                                            <input type="text" id="km" name="km_ricons" class="form-control" value="<?=$tr['km_cons']?>">
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                    
                                                                    <?php
                                                                        if( file_exists("docs/testride/sign/".$cli['id']."_sig_ricons_tr_".$tr['id'].".png")){

                                                                        
                                                                        ?>
                                                                    <img src="docs/testride/sign/<?=$cli['id']?>_sig_ricons_tr_<?=$tr['id']?>.png" >
                                                                        <?php }else{ ?>
                                                                    
                                                                    <div class="col-12">
                                                                        <div class="form-group row"  style="height: 300px;">
                                                                                    
                                                                                        <div id="signature-pad" class="m-signature-pad" style="width: 450px;height: 200px;">
                                                                                            <div class="m-signature-pad--body">
                                                                                                <canvas width="450" height="200"></canvas>
                                                                                            </div>
                                                                                            
                                                                                            <div class="m-signature-pad--footer">
                                                                                                <div class="description" style="padding-top: 20px;">
                                                                                                </div>
                                                                                                <button type="button" class="button btn btn-primary clear" data-action="clear">Pulisci Campo Firma</button>
                                                                                            </div>
                                                                                        </div> 
                                                                            </div>             
                                                                    </div> 
                                                                    <?php } ?>       

                                                                    <div class="col-12  ">
                                                                        <div class="form-group row">
                                                                            <label class="col-sm-4 col-form-label">FotoReport</label>
                                                                            <div class="col-sm-8">
                                                                            <input type="file" id="freport" name="freport"  class="" >
                                                                            <textarea rows="3" class="form-control" id="basic-textarea"></textarea>
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group row">
                                                                            <label class="col-sm-4 col-form-label">FotoReport2</label>
                                                                            <div class="col-sm-8">
                                                                            <input type="file" id="freport2" name="freport2"  class=""> 
                                                                            <textarea rows="3" class="form-control" id="basic-textarea"></textarea>                                   </div>
                                                                        </div>
                                                                    </div>            
                                                            </div>
                                                            <div class="modal-footer">
                                                                <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Chiudi</button>
                                                                <button type="submit" class="btn btn-success"onclick="conferma();"><i class="fa fa-check-square-o"></i> Conferma Riconsegna</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>                        
                                            </div>
                                <?          }

                                
                                        }  

                                    }else{?>
                                            <tr colspan="4"><td style="text-align: center;">Siamo spiacenti! Non ci sono Test Ride On the Road !</td></tr>
                                    <?}?>  
                            </tbody>            
                        </table>
                    </div>            
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-6 col-md-12">
        <div id="calendar"></div>
    </div>





    