<div class="row">
    <div class="col-12">

        <div class="card" style=" background-color: #dee2e68c;"> <!-- main card-->
            <div class="card-header" style="background-color: lightgray;box-shadow:inset 0px 0px 12px 0px black">
                <div class="row">
                    <div class="col-md-3"><h3 style="text-shadow: 4px 2px 2px #c6c6c6;">TestRide #<?=$tr['id']?></h3>
                    </div>
                    <div class="col-md-8"> 
                        <div>
                            <button style="float: right;margin-left:10px;" type="reset" class="btn btn-warning" onclick="history.back();return false;" value="Annulla">
                            <i class="fa fa-undo fa-2x"></i> <span style="vertical-align: super;">Indietro</span>
                            </button>
                        </div>  
                        <div> 
                            <button style="float: right;margin-left:10px;display:<?=$tr['data_cons']?'':'none'?>;" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle btn btn-primary">
                            <i class="fa fa-print fa-2x"></i> <span style="vertical-align: super;">Stampa Report</span>
                            </button>
                            <div tabindex="-1" aria-hidden="true" role="menu" class="dropdown-menu" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 38px, 0px); top: 0px; left: 0px; will-change: transform;">
                                <button type="button" tabindex="0" class="dropdown-item" onclick="prtPdf()">Stampa Modulo Consegna Veicolo</button>
                                <button style="<?=$tr['data_ricons']?'':'display:none'?>;" type="button" tabindex="0" class="dropdown-item" onclick="prtPdf2()">Stampa Modulo Riconsegna</button>
                               
                                <div tabindex="-1" class="dropdown-divider"></div>
                                    <button style="<?=$tr['data_ricons']?'':'display:none'?>;" type="button" tabindex="0" class="dropdown-item" onclick="prtPdf3()">Stampa Report TestRide Integrale</button>
                                
                                </div>
                                
                            </div>
                            <div> 
                                <button style="float: right;margin-left:10px;" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="dropdown-toggle btn btn-success">
                                    <i class="fa fa-cog fa-2x"></i> <span style="vertical-align: super;">Gestione </span>
                                </button>
                                <div tabindex="-1" aria-hidden="true" role="menu" class="dropdown-menu" x-placement="bottom-start" style="position: absolute; transform: translate3d(0px, 38px, 0px); top: 0px; left: 0px; will-change: transform;">
                                    <a href="<?=$updateUrl?>?action=update&id=<?=$tr['id']?>" class="dropdown-item waves-effect waves-light"><i class="fa fa-edit"></i> Modifica Prenotazione</a>
                                    <a  tabindex="0" class="dropdown-item waves-effect waves-light" style="<?=$tr['id_cliente']?'':'display:none;'?>" data-toggle="modal" data-target="#modal-animation-3"><i class="fa fa-sign-out" aria-hidden="true"></i> Gestione Consegna</a>
                                    <a style="<?=$tr['data_cons']?'':'display:none'?>;" tabindex="1" class="dropdown-item waves-effect waves-light" data-toggle="modal" data-target="#modal-animation-4"><i class="fa fa-sign-in" aria-hidden="true"></i> Gestione Riconsegna</a>
                                </div>
                            </div>  
                            <div>   
                                <button style="float: right;margin-left:10px;" class="btn btn-danger" onclick="if(confirm('Cancellare questo record?')) document.location.href='<?=$deleteUrl?>?id=<?=$tr['id']?>&action=delete'">
                                <i class="fa fa-trash fa-2x"></i> <span style="vertical-align: super;">Elimina  </span>
                                
                                </button>
                            </div>
                    </div>
                </div>
            </div><!-- end card header-->
            <div class="card-body">
                <div class="row"> 
                    <div class="col-lg-5 col-md-12">
                        <div class="card">
                            <div class="card-header" style="font-size:large;"><i class="fa fa-user"></i> Dati Cliente
                            </div>
                            <div class="card-body">
                                <div class="input-group-prepend col-lg-12 col-md-12" style="display:<?=$tr['id_cliente']?'none':''?>">
                                    <span class="input-group-text"><i class="fa fa-barcode"></i></span>
                                    <input type="text" id="autocomplete" name="autocomplete"  value="" maxlength="16" placeholder="Inserisci / Scansione Codice Fiscale - Ricerca per Nome/Cognome - Ricerca per Email-cellulare" class="form-control ui-autocomplete-input"  autocomplete="off">       
                                </div>
                            <button type="button" class="btn btn-primary btn-block m-1" data-keyboard="false" data-backdrop="static" style="display:<?=$idCli?'none':''?>" data-toggle="modal" data-target="#modalcliente"><i class="fa fa-user-plus"></i> Inserimento Nuovo Cliente </button>
                                    
                            

                                <div class=" col-12" id="datcli" <?=$idCli?'':'style="display:none;"'?>> <!-- scheda cliente-->
                                        <ul class="list-group">
                                            <li class="list-group-item">
                                                <div class="media align-items-center">
                                                <div class="media-body ml-3">
                                                
                                                <h6 class="mb-0" style="display:inline;">Id Cliente</h6>
                                                
                                                </div>
                                                <div class="date" style="text-align: right;">
                                                <b><?=$cli['id']?></b>
                                                </div>
                                                </div>
                                            </li>
                                            <li class="list-group-item">
                                                <div class="media align-items-center">
                                                <div class="media-body ml-3">
                                                <h6 class="mb-0">Nominativo</h6>
                                                </div>
                                                <div class="date">
                                                <b><?=$cli['cognome']?> <?=$cli['nome']?></b><br>
                                                CF <?=$cli['codfiscale']?>
                                                </div>
                                                </div>
                                            </li>
                                            <li class="list-group-item">
                                                <div class="media align-items-center">
                                                <div class="media-body ml-3">
                                                <h6 class="mb-0" style="display:inline;">Dati Anagrafici</h6>
                                                    <?php if($checkanagrcli){?>
                                                    <button type="button" class="btn btn-success m-1" data-keyboard="false" data-backdrop="static" data-toggle="modal" data-target="#modalcliente" title="Aggiorna Dati"> <i class="fa fa-check"></i> </button>
                                                    <?}else{?>
                                                    <button type="button" class="btn btn-danger m-1" data-keyboard="false" data-backdrop="static" data-toggle="modal" data-target="#modalcliente" title="Aggiorna Dati"> <i class="fa fa-exclamation-triangle"></i> </button>
                                                    <?}?>
                                                
                                                </div>
                                                <div class="date">
                                                nato a <?=getComune($cli['luogonasc']);?>(<?=$cli['provnasc']?>)<br>il <?=date("d/m/Y", strtotime($cli['datanasc']))?>
                                                </div>
                                                </div>
                                            </li>
                                            <li class="list-group-item">
                                                <div class="media align-items-center">
                                                <div class="media-body ml-3">
                                                <h6 class="mb-0" style="display:inline;">Dati Residenza</h6>
                                                <?php if($checkrescli){?>
                                                    <button type="button" class="btn btn-success m-1" data-keyboard="false" data-backdrop="static" data-toggle="modal" data-target="#modalcliente" title="Aggiorna Dati"> <i class="fa fa-check"></i> </button>
                                                    <?}else{?>
                                                    <button type="button" class="btn btn-danger m-1" data-keyboard="false" data-backdrop="static" data-toggle="modal" data-target="#modalcliente" title="Aggiorna Dati"> <i class="fa fa-exclamation-triangle"></i> </button>
                                                    <?}?>
                                                </div>
                                                <div class="date">
                                                <?=$cli['indirizzores']?><br>
                                                <?=$cli['capres']?> - <?=getComune($cli['luogores']);?>(<?=$cli['provres']?>)
                                                </div>
                                                </div>
                                            </li>
                                            <li class="list-group-item">
                                                <div class="media align-items-center">
                                                <div class="media-body ml-3">
                                                <h6 class="mb-0" style="display:inline;">Contatti</h6>
                                                <?php if($cli['mail1']&&$cli['mobile1']){?>
                                                    <button type="button" class="btn btn-success m-1" data-keyboard="false" data-backdrop="static" data-toggle="modal" data-target="#modalcliente" title="Aggiorna Dati"> <i class="fa fa-check"></i> </button>
                                                    <?}else{?>
                                                    <button type="button" class="btn btn-danger m-1" data-keyboard="false" data-backdrop="static" data-toggle="modal" data-target="#modalcliente" title="Aggiorna Dati"> <i class="fa fa-exclamation-triangle"></i> </button>
                                                    <?}?>
                                                </div>
                                                <div class="date">
                                                    Email <?=$cli['mail1']?><br>
                                                    Cellulare <?=$cli['mobile1']?>
                                                </div>
                                                </div>
                                            </li>
                                            <li class="list-group-item">
                                                <div class="media align-items-center">
                                                <div class="media-body ml-3">
                                                <h6 class="mb-0" style="display:inline;">Dati Patente </h6>
                                                <?php if($checkpat&&date("Y-m-d") < $patente['data_scadenza']){?>
                                                    <button type="button" class="btn btn-success m-1" data-keyboard="false" data-backdrop="static" data-toggle="modal" data-target="#modalcliente" title="Aggiorna Dati"> <i class="fa fa-check"></i> </button>
                                                
                                                            
                                                    <?}else{?>
                                                    <button type="button" class="btn btn-danger m-1" data-keyboard="false" data-backdrop="static" data-toggle="modal" data-target="#modalcliente" title="Aggiorna Dati"> <i class="fa fa-exclamation-triangle"></i> </button>
                                                    <?}?>
                                                </div>
                                                <div class="date">
                                                numero <b><?=$patente['numero_patente']?></b> tipo <b><?=$patente['tipo_patente']?></b>
                                                <br>    validità dal <b><?=date("d/m/Y", strtotime($patente['data_rilascio']))?></b> al <b><?=date("d/m/Y", strtotime($patente['data_scadenza']))?></b>
                                                <br>rilasciata da <b><?=$patente['ente_rilascio']?></b>
                                                </div>

                                                </div>
                                            </li>
                                            <li class="list-group-item">
                                                <div class="media align-items-center">
                                                <div class="media-body ml-3">
                                                <h6 class="mb-0" style="display:inline;">Scansione Patente</h6>
                                                <?php if($checkpatdoc){?>
                                                    <button type="button" class="btn btn-success m-1" data-toggle="modal" data-target="#imagemodal1" title="Visualizza Documento"> <i class="fa fa-check"></i> </button>
                                                
                                                            
                                                    <?}else{?>
                                                    <button type="button" class="btn btn-danger m-1" data-keyboard="false" data-backdrop="static" data-toggle="modal" data-target="#modalcliente" title="Aggiorna Dati"> <i class="fa fa-exclamation-triangle"></i> </button>
                                                    <?}?>
                                                </div>
                                                <div class="date">
                                                
                                                </div>

                                                </div>
                                            </li>
                                        
                                        </ul>
                                    <form id="addform" action="controller/updateTestride.php" method="post">   
                                        <input type="hidden" name="id_clientenew" id="id_cliente_new" value="<?=$cli['codfiscale']?>">
                                        <input type="hidden" name="idTr" value="<?=$tr['id']?>">
                                        <input type="hidden" name="action" value="storeTestridePage">
                                        <button type="button" class="btn btn-primary btn-block m-1" data-keyboard="false" data-backdrop="static" style="display:<?=$tr['id_cliente']?'none':''?>" data-toggle="modal" data-target="#modalcliente"><i class="fa fa-edit"></i> Modifica dati Cliente </button>
                                        <button type="submit" id="saveMod"class="btn btn-success btn-block m-1" style="display:<?=$tr['id_cliente']?'none':''?>;" ><i class="fa fa-<?=$cli?'edit':'user-plus'?>"></i> Salva Modifiche Prenotazione</button>
                   
                                    </form>                        
                                </div>

                            </div>
                        </div>
                        

                    </div>
                    <div class="col-lg-4 col-md-12">
                        <div class="card">
                            <div class="card-header" style="font-size:large;"><i class="fa fa-motorcycle"></i> Dati TestRide
                            </div> 
                                <ul class="list-group list-group-flush shadow-none">
                                    <li class="list-group-item">
                                        <div class="media align-items-center">
                                            <div class="media-body ml-3">
                                                <h6 class="mb-0">Motoveicolo</h6>
                                            </div>
                                            <div class="date">
                                                <b><?=$veicolo['marca']?> <?=$veicolo['modello']?></b>
                                            </div>
                                        </div>
                                    </li>

                                    <li class="list-group-item">
                                        <div class="media align-items-center">
                                            <div class="media-body ml-3">
                                                <h6 class="mb-0">Targa</h6>
                                            </div>
                                            <div class="date">
                                                <b><?=$veicolo['targa']?></b>
                                            </div>
                                        </div>
                                    </li>
                                </ul>
                            <div class="card-header" style="font-size:large;"><i class="fa fa-calendar-check-o"></i> Dati Prenotazione
                            </div>	
                                <ul class="list-group list-group-flush shadow-none">
                                    <li class="list-group-item">
                                        <div class="media align-items-center">
                                            <div class="media-body ml-3">
                                                <h6 class="mb-0">Consulente</h6>
                                            </div>
                                            <div class="date">
                                                <b> <?=$tr['user_pren']?></b>
                                            </div>
                                        </div>
                                    </li>

                                    <li class="list-group-item">
                                        <div class="media align-items-center">
                                            <div class="media-body ml-3">
                                                <h6 class="mb-0">Data/Ora</h6>
                                            </div>
                                            <div class="date">
                                                <b><?=$tr['data_pren']?></b>
                                            </div>
                                        </div>
                                    </li>
                                    <?php if($tr['data_pren']){ ?>    
                                    <li class="list-group-item" style="display:<?=$tr['data_cons']?'':'none'?>">
                                        <div class="media align-items-center">
                                            <div class="media-body ml-3">
                                                <h6 class="mb-0">Consegna Moto</h6>
                                            </div>
                                            <div class="date">
                                                <i class="fa fa-calendar"></i> Data/Ora <b><?=$tr['data_cons']?></b><br>
                                                <i class="fa fa-user"></i> Consulente <b><?=$tr['user_cons']?></b><br>
                                                <i class="fa fa-sort-numeric-asc"></i> KM Consegna <b><?=$tr['km_cons']?></b>
                                            </div>
                                        </div>
                                    </li>
                                    <? } ?>
                                    <?php if($tr['data_ricons']){ ?>         
                                    <li class="list-group-item">
                                        <div class="media align-items-center">
                                            <div class="media-body ml-3">
                                                <h6 class="mb-0">Riconsegna Moto</h6>
                                            </div>
                                            <div class="date">
                                                <i class="fa fa-calendar"></i> Data/Ora <b><?=$tr['data_ricons']?></b><br>
                                                <i class="fa fa-user"></i> Consulente <b><?=$tr['user_ricons']?></b><br>
                                                <i class="fa fa-sort-numeric-asc"></i> KM Consegna <b><?=$tr['km_ricons']?></b>
                                                <i class="fa fa-hourglass"></i> Durata <b><?=$tr['durata_test']?> minuti</b><br>
                                            </div>
                                        </div>
                                    </li>
                                    <? } ?>            
                                </ul>
                            <div class="card-header" style="font-size:large;"><i class="fa fa-calendar-check-o"></i> Note Prenotazione
                                <ul class="list-group list-group-flush shadow-none">
                                    <li class="list-group-item">
                                        <div class="media align-items-center">
                                            
                                            <div class="date">
                                                <b> <?=$tr['note_pren']?></b>
                                            </div>
                                        </div>
                                    </li>
                                </ul>                        
                            </div>    
                        </div>
                    </div>
                    <div class="col-md-12 col-lg-3">
                        <div class="card">
                            <div class="card-header" style="font-size:large;"><i class="fa fa-motorcycle"></i> Archivio Report
                            </div> 
                                <ul class="list-group list-group-flush shadow-none">
                                    <li class="list-group-item">
                                        <div class="media align-items-center">
                                            <div class="media-body ml-3">
                                                <h6 class="mb-0">Report Consegna</h6>
                                            </div>
                                            <div class="date">
                                            <?php
                                            if( file_exists("docs/testride/report/".$tr['id']."_cons.pdf")){

                                            
                                            ?>
                                            <button type="button"  id="btnPdf1" class="btn btn-danger m-1" onClick="btnPdf1();"> <i aria-hidden="true" class="fa fa-file-pdf-o"></i> </button>
                                            
                                            <? } ?>
                                            </div>
                                        </div>
                                    </li>

                                    <li class="list-group-item">
                                        <div class="media align-items-center">
                                            <div class="media-body ml-3">
                                                <h6 class="mb-0">Report Riconsegna</h6>
                                            </div>
                                            <div class="date">
                                            <?php
                                            if( file_exists("docs/testride/report/".$tr['id']."_ricons.pdf")){

                                            
                                            ?>
                                            <button type="button"  id="btnPdf2" class="btn btn-danger m-1" onClick="btnPdf2();"> <i aria-hidden="true" class="fa fa-file-pdf-o"></i> </button>
                                            
                                            <? } ?>
                                            </div>
                                        </div>
                                    </li>
                               
                            	
                                
                                    <li class="list-group-item">
                                        <div class="media align-items-center">
                                            <div class="media-body ml-3">
                                                <h6 class="mb-0">Report Integrale</h6>
                                            </div>
                                            <div class="date">
                                            <?php
                                            if( file_exists("docs/testride/report/".$tr['id']."_full.pdf")){

                                            
                                            ?>
                                            <button type="button"  id="btnPdf3" class="btn btn-danger m-1" onClick="btnPdf3();"> <i aria-hidden="true" class="fa fa-file-pdf-o"></i> </button>
                                            
                                            <? } ?>  
                                            </div>
                                        </div>
                                    </li>
                                    
                                </ul>           
                                    
                                   
                    </div>
                </div> <!-- end row card body-->

            </div><!-- end card row-->
                <div class="modal fade" id="modal-animation-3" style="display: none;" aria-hidden="true">
                    <form enctype="multipart/form-data"  id="upform" action="controller/updateTestride.php" method="post"> 
                    <input type="hidden" id="id" name="id" value="<?=$tr['id']?>">
                    <input type="hidden" id="id_cliente" name="id_cliente" value="<?=$checkanagrcli?$cli['id']:$idCli?>">
                    <input type="hidden" name="action" value ="storeTestrideCons">
                    <input type="hidden" name="signCode2" id="signCode2" value="">  
                        <div class="modal-dialog modal-lg modal-dialog-centered">
                            <div class="modal-content animated slideInUp">
                                <div class="modal-header">
                                    <h5 class="modal-title">Consegna moto TestRide</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                <div class="modal-body" style="display:<?=$checkpat&&$cfCli&&$tr['id_cliente']?'':'none'?>">
                                        <div class="col-12  ">
                                            <div class="form-group row">
                                                <label class="col-sm-4 col-form-label">KM</label>
                                                <div class="col-sm-8">
                                                <input type="text" id="km" name="km_cons" class="form-control" value="<?=$tr['km_cons']?$tr['km_cons']:0.0?>">
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <?php
                                        
                                            if(file_exists("docs/testride/sign/".$cli['id']."_sig_cons_tr_".$tr['id'].".png")){

                                            
                                            ?>
                                        <img src="docs/testride/sign/<?=$cli['id']?>_sig_cons_tr_<?=$tr['id']?>.png" >
                                            <?php
                                        }else{ ?>
                                        
                                        <div class="col-12">
                                            <div class="form-group row"  style="height: 300px;">
                                            			
                                                             <div id="signature-pad2" class="m-signature-pad" style="width: 450px;height: 200px;">
                                                                <div class="m-signature-pad--body">
                                                                    <canvas width="450" height="200"></canvas>
                                                                </div>
                                                                
                                                                <div class="m-signature-pad--footer">
                                                                    <div class="description" style="padding-top: 20px;">
                                                                    </div>
                                                                    <button type="button" class="button btn btn-primary clear" data-action="clear">Pulisci Campo Firma</button>
                                                                </div>
                                                            </div> 
                                                </div>             
                                        </div> 
                                        <?php } 
                                        ?>       

                                        <div class="col-12  ">
                                            <div class="form-group row">
                                                <label class="col-sm-4 col-form-label">FotoReport</label>
                                                <div class="col-sm-8">
                                                <input type="file" id="freport" name="freport"  class="" >
                                                <textarea rows="3" class="form-control" id="basic-textarea" id="report1" name="report1"></textarea>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-sm-4 col-form-label">FotoReport2</label>
                                                <div class="col-sm-8">
                                                <input type="file" id="freport2" name="freport2"  class=""> 
                                                <textarea rows="3" class="form-control" id="basic-textarea" id="report2" name="report2"></textarea>                                   </div>
                                            </div>
                                        </div>            
                                </div>
                                <div class="modal-body" style="display:<?=$cfCli?'none':''?>">
                                            <div class="col-12">
                                                Dati clienti Mancanti!
                                            </div>
                                            
                                </div>
                                
                                <div class="modal-body" style="display:<?=$checkpat?'none':''?>">
                                            <div class="col-12">
                                            Dati patente mancanti
                                            </div>
                                            
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Annulla</button>
                                    <button type="submit" class="btn btn-success"onclick="confCons();" <?php 
                                                                                                            if(!$cfCli){
                                                                                                                echo 'disabled title="Inserire/Scegliere Cliente"' ;
                                                                                                            }
                                                                                                            elseif(!$checkpat){
                                                                                                                echo 'disabled title="Inserire Dati Patente"' ;

                                                                                                            }elseif(!$tr['id_cliente']){
                                                                                                                echo 'disabled title="Salvare modifiche prenotazione"' ;
                                                                                                            }    
                                                                                                        ?>
                                    >
                                    <i class="fa fa-check-square-o"></i> Conferma Consegna</button>
                                </div>
                            </div>
                        </div>
                    </form>                         
                </div>
                <div class="modal fade" id="modal-animation-4" style="display: none;" aria-hidden="true">
                    <form id="upform" action="controller/updateTestride.php" method="post"> 
                    <input type="hidden" id="id" name="id" value="<?=$tr['id']?>">
                    <input type="hidden" id="id_cliente" name="id_cliente" value="<?=$cli['id']?>">
                    <input type="hidden" name="action" value ="storeTestrideRicons">
                    <input type="hidden" name="signCode" id="signCode" value="">
                    <input type="hidden" name="data_cons" id="data_cons" value="<?=$tr['data_cons']?>" >
                    <input type="hidden" id="id_veicolo" name="id_veicolo" value="<?=$tr['id_veicolo']?>">
                        <div class="modal-dialog modal-dialog-centered">
                            <div class="modal-content animated slideInUp">
                                <div class="modal-header">
                                    <h5 class="modal-title">Riconsegna moto TestRide</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                        <div class="col-12  ">
                                            <div class="form-group row">
                                                <label class="col-sm-4 col-form-label">KM</label>
                                                <div class="col-sm-8">
                                                <input type="number" min="<?=$tr['km_cons']?>" id="km" name="km_ricons" class="form-control" value="<?=$tr['km_cons']?>">
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <?php
                                            if( file_exists("docs/testride/sign/".$cli['id']."_sig_ricons_tr_".$tr['id'].".png")){

                                            
                                            ?>
                                        <img src="docs/testride/sign/<?=$cli['id']?>_sig_ricons_tr_<?=$tr['id']?>.png" >
                                            <?php }else{ ?>
                                        
                                        <div class="col-12">
                                            <div class="form-group row"  style="height: 300px;">
                                            			
                                                             <div id="signature-pad" class="m-signature-pad" style="width: 450px;height: 200px;">
                                                                <div class="m-signature-pad--body">
                                                                    <canvas width="450" height="200"></canvas>
                                                                </div>
                                                                
                                                                <div class="m-signature-pad--footer">
                                                                    <div class="description" style="padding-top: 20px;">
                                                                    </div>
                                                                    <button type="button" class="button btn btn-primary clear" data-action="clear">Pulisci Campo Firma</button>
                                                                </div>
                                                            </div> 
                                                </div>             
                                        </div> 
                                        <?php } ?>       

                                        <div class="col-12  ">
                                            <div class="form-group row">
                                                <label class="col-sm-4 col-form-label">FotoReport</label>
                                                <div class="col-sm-8">
                                                <input type="file" id="freport" name="freport"  class="" >
                                                <textarea rows="3" class="form-control" id="basic-textarea"></textarea>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label class="col-sm-4 col-form-label">FotoReport2</label>
                                                <div class="col-sm-8">
                                                <input type="file" id="freport2" name="freport2"  class=""> 
                                                <textarea rows="3" class="form-control" id="basic-textarea"></textarea>                                   </div>
                                            </div>
                                        </div>            
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Chiudi</button>
                                    <button type="submit" class="btn btn-success"onclick="conferma();"><i class="fa fa-check-square-o"></i> Conferma Riconsegna</button>
                                </div>
                            </div>
                        </div>
                    </form>                        
                </div>
                <div class="modal fade" id="modal-animation-5" aria-hidden="true" style="display: none;">
                    <div class="modal-dialog modal-dialog-centered">
                        <form id="addform" action="controller/updateAnagr_cli.php" method="post">
                            <input type="hidden" name="action" value ="newPatenteTr">
                            <input type="hidden" name="id_cliente" value ="<?=$cli['codfiscale']?>">
                            <input type="hidden" name="id" value ="<?=$cli['id']?>">
                            <input type="hidden" name="idTr" value ="<?=$tr['id']?>">

                            <div class="modal-content">
                                
                                <div class="modal-header">
                                    <h5 class="modal-title">Aggiornamento Dati Patente</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                                
                                <div class="modal-body">
                
                                        <div class="form-group row">
                                        <label class="col-sm-4 col-form-label">Data Rilascio</label>
                                            <div class="col-sm-8">
                                                <input type="date" name="data_rilascio" class="form-control" value="">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                        <label class="col-sm-4 col-form-label">Data scadenza</label>
                                            <div class="col-sm-8">
                                                <input type="date" name="data_scadenza" class="form-control" value="">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                        <label class="col-sm-4 col-form-label">ente Rilascio</label>
                                            <div class="col-sm-8">
                                                <input type="text" name="ente_rilascio" class="form-control" placeholder="Inserire Ente" value="">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                        <label class="col-sm-4 col-form-label">Numero</label>
                                            <div class="col-sm-8">
                                                <input type="text" name="numero_patente" placeholder="Inserire Numero" class="form-control" value="">
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                        <label class="col-sm-4 col-form-label">Tipo Patente</label>
                                            <div class="col-sm-8">
                                            <select class="form-control" name="tipo_patente" id="default-select">
                                            <?php if($patente['tipo_patente']){ ?>
                                                    <option value="<?=$patente['tipo_patente']?>" selected> <?=$patente['tipo_patente']?></option>
                                            <?php } ?>
                                                <option value="">Seleziona Tipo patente</option>
                                                <option value="CIGC">CIGC</option>
                                                <option value="AM">AM</option>
                                                <option value="AM-B">AM-B</option>
                                                <option value="A1">A1</option>
                                                <option value="A1-B">A1-B</option>
                                                <option value="A2">A2</option>
                                                <option value="A2-B">A2-B</option>
                                                <option value="A">A</option>
                                                <option value="A-B">A-B</option>
                                                <option value="B">B</option>
                                            </select>
                                            </div>
                                        </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Annulla</button>
                                    <button type="submit" class="btn btn-success"><i class="fa fa-check-square-o"></i> Aggiorna</button>
                                </div>
                            
                            </div>
                        </form>								
                    </div>
                </div>
                <div class="modal fade" id="modalcliente" style="display: none;" aria-hidden="true">
                        <div class="modal-dialog modal-lg modal-dialog-centered">
                            
                            <form enctype="multipart/form-data" id="addformcli" action="controller/updateAnagr_cli.php" method="post">
                            <?php if($idCli){?>
                                <input type="hidden" name="id" value ="<?=$cli['id']?>">
                                <input type="hidden" name="action" value ="storeClientePageTr">
                            <?}else{?>

                                <input type="hidden" name="action" value ="saveClientePageTr">     
                            <?}?>
                             
                                <input type="hidden" name="idTr" value="<?=$tr['id']?>">
                                
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title"><?=$cli?'Aggiornamento Dati':'Inserimento Nuovo'?> Cliente</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">×</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <div id="datianagr_modal" style="<?=$idCli?'display:none;':''?>">
                                                <div class="col-12 "> 
                                                    <div class="row form-group">
                                                        <div class="col col-md-12">
                                                        <h5><i class="fa fa-user"></i> Dati Anagrafici</h5>                                                   </h5></div>
                                                    </div>
                                                </div>
                                                <div class="row col-12">      
                                                    <div class="col-12 ">
                                                        <div class="form-group row">
                                                            <label class="col-sm-4 col-form-label">Ragione sociale</label>
                                                            <div class="col-sm-8">
                                                        <input type="text" id="ragsociale" name="ragsociale" value="<?=$idCli?$cli['ragsociale']:''?>" placeholder="Inserire Ragione Sociale" class="form-control">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            
                                                <div class="row col-12">    
                                                    <div class="col-6 col-md-12">
                                                        <div class="form-group row ">
                                                                <label class="col-sm-4 col-form-label">Cognome</label>
                                                            <div class="col-sm-8">
                                                                <input type="text" id="cognome" name="cognome" value="<?=$idCli?$cli['cognome']:''?>" placeholder="Inserire Cognome" class="form-control"required>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-6 col-md-12">
                                                        <div class="form-group row ">
                                                            <label class="col-sm-4 col-form-label">Nome</label>
                                                            <div class="col-sm-8">
                                                                <input type="text" id="nome" name="nome" value="<?=$idCli?$cli['nome']:''?>" placeholder="Inserire Nome" class="form-control" required>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div> 

                                                <div class="row col-12"> 
                                                    <div class="col-6 col-md-12"> 
                                                        <div class="form-group row">
                                                            <label class="col-sm-4 col-form-label">Prov di Nascita</label>
                                                            <div class="col-sm-8">
                                                                <select class="form-control" id="provnasc" name="provnasc"  required>
                                                                    <optgroup>
                                                                    
                                                                    </optgroup>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-6 col-md-12">
                                                        <div class="form-group row ">
                                                            <label class="col-sm-4 col-form-label">Luogo di Nascita</label>
                                                            <div class="col-sm-8">
                                                                <select class="form-control" name="luogonasc" id="luogonasc">
                                                                <optgroup></optgroup>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="row col-12"> 
                                                    <div class="col-6 col-md-12">
                                                        <div class="form-group row">
                                                            <label class="col-sm-4 col-form-label">Data di Nascita</label>
                                                            <div class="col-sm-8">
                                                                <input type="date" id="datanasc" name="datanasc" class="form-control" value="<?=$cli['datanasc']?>" required>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-6 col-md-12">
                                                        <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Nazionalita</label>
                                                            <div class="col-sm-8">
                                                        <input type="text" id="nazionalita" name="nazionalita" value="<?=$idCli?$cli['nazionalita']:'I'?>" class="form-control">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>            
                                                <div class="row col-12"> 
                        
                                                    <div class="col-6 col-md-12">
                                                        <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Sesso</label>
                                                            <div class="col-sm-8">
                                                        
                                                            <select class="form-control" id="sesso" name="sesso" required>
                                                            <option value="">Seleziona</option>
                                                            <?php

                                                                if($idCli){?>
                                                                <option value="<?=$cli['sesso']?>" <?=$cli['sesso']?'selected':''?>> <?=$cli['sesso'] === 'M'?'Maschio':'Femmina'?> </option>


                                                            <?php   }else{ ?>

                                                                    <option value="M">Maschio</option>
                                                                    <option value="F">Femmina</option>

                                                            <?php       
                                                            }
                                                            
                                                            ?>



                                                            
                                                        </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row col-12"> 

                                                    <div class="col-12 ">
                                                        <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Codice Fiscale</label>
                                                            <div class="col-sm-4">
                                                        <input type="text" id="codfiscale" name="codfiscale" maxlength="16" class="form-control" value="<?=$idCli?$cli['codfiscale']:''?>" required>
                                                            </div>
                                                            <div class="col-sm-4"><button class="btn btn-primary" id="cf"><i class="fa fa-id-card"></i> Calcolo codice</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="row col-12"> 
                                                    <div class="col-12">
                                                        <div class="form-group row">
                                                            <label class="col-sm-4 col-form-label">Partita Iva</label>
                                                            <div class="col-sm-4">
                                                                <input type="text" id="partitaiva" name="partitaiva" value="<?=$idCli?$cli['partitaiva']:''?>" placeholder="Inserire Partita Iva" class="form-control">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>    
                                                <div class="col-12 ">
                                                    <div class="row form-group">
                                                        <div class="col col-md-12">
                                                            <h5><i class="fa fa-home"></i> Dati Residenza</h5>
                                                        </div>
                                                    </div>
                                                </div>


                                            <div class="row col-12">     
                                                <div class="col-12 ">
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Indirizzo</label>
                                                        <div class="col-sm-8">
                                                    <input type="text" id="indirizzores" name="indirizzores" value="<?=$idCli?$cli['indirizzores']:''?>" placeholder="Inserire Indirizzo" class="form-control">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row col-12">    
                                                <div class="col-6 col-md-12">
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Provincia</label>
                                                        <div class="col-sm-8">
                                                            <select id="provres" name="provres" class="form-control">
                                                            
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-6 col-md-12">
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Comune</label>
                                                        <div class="col-sm-8">
                                                                <select id="luogores" name="luogores" class="form-control"></select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row col-12">     
                                                <div class="col-12 ">
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">CAP</label>
                                                        <div class="col-sm-4">
                                                            <input type="text" id="capres" name="capres" maxlength="5" value="<?=$idCli?$cli['capres']:''?>" placeholder="Inserire CAP" class="form-control">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>    
                                                <div class="col-12 ">
                                                <div class="row form-group">
                                                    <div class="col col-md-12">
                                                    <h5><i class="fa fa-tty"></i> Contatti</h5><h5>
                                                    </h5></div>
                                                </div>
                                                </div>
                                            <div class="row col-12">                                     
                                                <div class="col-12 ">
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">eMail 1</label>
                                                        <div class="col-sm-8">
                                                    <input type="email" id="mail1" name="mail1" value="<?=$idCli?$cli['mail1']:''?>"placeholder="Inserire eMail 1" class="form-control" required>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row col-12">     
                                                <div class="col-12 ">
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">eMail 2</label>
                                                        <div class="col-sm-8">
                                                    <input type="email" id="mail2" name="mail2" value="<?=$idCli?$cli['mail2']:''?>" placeholder="Inserire eMail 2" class="form-control">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>    
                                            <div class="row col-12"> 
                                                <div class="col-6 col-md-12 ">
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Telefono 1</label>
                                                        <div class="col-sm-8">
                                                    <input type="text" id="tel1" name="tel1" maxlength="15" value="<?=$idCli?$cli['tel1']:''?>" placeholder="Inserire Telefono 1" class="form-control">
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-6 col-md-12">
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Telefono 2</label>
                                                        <div class="col-sm-8">
                                                    <input type="text" id="tel2" name="tel2" maxlength="15" value="<?=$idCli?$cli['tel2']:''?>" placeholder="Inserire Telefono 2" class="form-control">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row col-12">     
                                                <div class="col-6 col-md-12">
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Mobile 1</label>
                                                        <div class="col-sm-8">
                                                    <input type="text" id="mobile1" name="mobile1" maxlength="15" value="<?=$idCli?$cli['mobile1']:''?>" placeholder="Inserire Mobile 1" class="form-control" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-6 col-md-12">
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Mobile 2</label>
                                                        <div class="col-sm-8">
                                                    <input type="text" id="mobile2" name="mobile2" maxlength="15" value="<?=$idCli?$cli['mobile2']:''?>" placeholder="Inserire Mobile 2" class="form-control">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-12"> 
                                                <div class="row form-group">
                                                    <div class="col col-md-12">
                                                        <h5><i class="fa fa-id-card"></i> Dati Patente di Guida</h5>
                                                    </div>
                                                </div>
                                            </div> 
                                            <div class="row col-12"> 

                                                <div class="col-6 col-md-12">
                                                    <div class="form-group row">
                                                    <label class="col-sm-4 col-form-label">Data Rilascio</label>
                                                        <div class="col-sm-8">
                                                            <input type="date" name="data_rilascio" id="data_rilascio_mod" class="form-control" value="<?=$idCli?$patente['data_rilascio']:''?>" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-6 col-md-12">
                                                    <div class="form-group row">
                                                    <label class="col-sm-4 col-form-label">Data scadenza</label>
                                                        <div class="col-sm-8">
                                                            <input type="date" name="data_scadenza" id="data_scadenza_mod"class="form-control" value="<?=$idCli?$patente['data_scadenza']:''?>" required>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="row col-12">
                                                <div class="col-6 col-md-12">
                                                    <div class="form-group row">
                                                    <label class="col-sm-4 col-form-label">ente Rilascio</label>
                                                        <div class="col-sm-8">
                                                            <input type="text" name="ente_rilascio" id="ente_rilascio_mod"class="form-control" placeholder="Inserire Ente" value="<?=$idCli?$patente['ente_rilascio']:''?>" required>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-6 col-md-12">
                                                    <div class="form-group row">
                                                    <label class="col-sm-4 col-form-label">Numero</label>
                                                        <div class="col-sm-8">
                                                            <input type="text" name="numero_patente" id="numero_patente_mod" placeholder="Inserire Numero" class="form-control" value="<?=$idCli?$patente['numero_patente']:''?>" required>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row col-12">
                                                <div class="col-6 col-md-12">
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Tipo Patente</label>
                                                        <div class="col-sm-8">
                                                            <select class="form-control" name="tipo_patente" id="tipo_patente_mod" required>
                                                            <?php if($idCli){ ?>
                                                                    <option value="<?=$patente['tipo_patente']?>" selected> <?=$patente['tipo_patente']?></option>
                                                            <?php } ?>
                                                                <option value="">Seleziona Tipo patente</option>
                                                                <option value="CIGC">CIGC</option>
                                                                <option value="AM">AM</option>
                                                                <option value="AM-B">AM-B</option>
                                                                <option value="A1">A1</option>
                                                                <option value="A1-B">A1-B</option>
                                                                <option value="A2">A2</option>
                                                                <option value="A2-B">A2-B</option>
                                                                <option value="A">A</option>
                                                                <option value="A-B">A-B</option>
                                                                <option value="B">B</option>
                                                            </select>
                                                        </div>
                                                     </div>
                                                </div>
                                            </div> 
                                            <div class="col-12"> 
                                                <div class="row form-group">
                                                    <div class="col col-md-12">
                                                    <h5><i aria-hidden="true" class="fa fa-cloud-download"></i> Acquisizione Patente</h5>
                                                    </div>
                                                </div>
                                            </div> 
                                            
                                                <div class="col-12 ">
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">Fronte</label>
                                                        <div class="col-sm-8">
                                                        <?php if($idCli){
                                                                if(file_exists("docs/CRM/Allegati/patente/".$cli['id']."_patfront.jpg")){?>
                                                                <button type="button" class="btn btn-success m-1"> <i class="fa fa-check"></i> </button> 
                                                                <img alt="Image placeholder" src="docs/CRM/Allegati/patente/<?=$cli['id']?>_patfront.jpg" class="product-img" data-toggle="modal" data-target="#imagemodal">

                                                       <? }else{?>
                                                            <input type="file" id="patfront" name="patfront" class="" required>
                                                            <?}
                                                        }else{?>
                                                        <input type="file" id="patfront" name="patfront" class="" required>
                                                        <?}?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-12 ">
                                                    <div class="form-group row">
                                                        <label class="col-sm-4 col-form-label">retro</label>
                                                        <div class="col-sm-8">
                                                        <?php
                                                        if($idCli){
                                                            if(file_exists("docs/CRM/Allegati/patente/".$cli['id']."_patrear.jpg")){?>
                                                            <button type="button" class="btn btn-success m-1"> <i class="fa fa-check"></i> </button>
                                                            <img alt="Image placeholder" src="docs/CRM/Allegati/patente/<?=$cli['id']?>_patrear.jpg" class="product-img" data-toggle="modal" data-target="#imagemodal">
                                                            <div class="col-lg-4 col-md-12 mb-4">

                                                           
                                                                      

                                                               

                                                            </div>
                                                               
                                                       <? }else{?>
                                                            <input type="file" id="patrear" name="patrear" class="" required>
                                                            <?}?>
                                                            <? }else{?>
                                                            <input type="file" id="patrear" name="patrear" class="" required>
                                                            <?}?>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <div class="col-12" <?php if($idCli){
                                                                                if(file_exists("docs/CRM/Allegati/patente/".$cli['id']."_patfront.jpg")){?>
                                                                               
                                                                               <? }else{?>
                                                                                        style="display:none;"
                                                                                 <?}
                                                                            }else{?>
                                                                                            style="display:none;"
                                                                            <?}?>
                                                        >
                                                                    
                                                </div>



                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Annulla</button>
                                            <button type="submit" class="btn btn-success"><i class="fa fa-check-square-o"></i> <?=$cli?'Aggiornamento Dati':'Inserimento Nuovo'?> Cliente</button>
                                        </div>
                                    </div>
                            </form>
                        </div>
                </div>
                <div class="modal fade" id="imagemodal1" style="display: none;" aria-hidden="true">
                                                                <div class="modal-dialog modal-lg modal-dialog-centered">
                                                                    <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title">Patente di <?=$cli['cognome'].' '.$cli['nome']?></h5>
                                                                        <button type="button" class="close" data-dismiss-modal="modal2" aria-label="Close">
                                                                        <span aria-hidden="true">×</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                    <img src="docs/CRM/Allegati/patente/<?=$cli['id']?>_patfront.jpg" style="height: 399px;padding: 25px;" alt="Card image cap">

                                                                        <img src="docs/CRM/Allegati/patente/<?=$cli['id']?>_patrear.jpg"  style="height: 399px;padding: 25px;" alt="Card image cap">
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-danger" data-dismiss-modal="modal2"><i class="fa fa-times"></i> chiudi</button>
                                                                        
                                                                    </div>
                                                                    </div>
                                                                </div>
                                                            </div>
        </div> <!--end main card -->
    </div>
</div>