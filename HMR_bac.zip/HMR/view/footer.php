<!--start overlay-->
<div class="overlay toggle-menu"></div>
	<!--end overlay-->
    </div>
    <!-- End container-fluid-->
    
    </div><!--End content-wrapper-->
   <!--Start Back To Top Button-->
    <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
    <!--End Back To Top Button-->
	
	<!--Start footer-->
	<footer class="footer" style="position:fixed;bottom:0px;z-index:100;">
      <div class="container">
        <div class="text-center">
          Powered by <img src="images/favicon.ico" style="width:20px;margin-bottom:2px;"> Setec S.r.l. © 2020 - All right Reserved
        </div>
      </div>
    </footer>
	<!--End footer-->
	
    <!--start color switcher-->
    <!--
   <div class="right-sidebar">
    <div class="switcher-icon">
      <i class="zmdi zmdi-settings zmdi-hc-spin"></i>
    </div>
    <div class="right-sidebar-content">
	
	
	 <p class="mb-0">Header Colors</p>
      <hr>
	  
	  <div class="mb-3">
	    <button type="button" id="default-header" class="btn btn-outline-primary">Default Header</button>
	  </div>
      
      <ul class="switcher">
        <li id="header1"></li>
        <li id="header2"></li>
        <li id="header3"></li>
        <li id="header4"></li>
        <li id="header5"></li>
        <li id="header6"></li>
      </ul>

      <p class="mb-0">Sidebar Colors</p>
      <hr>
	  
      <div class="mb-3">
	    <button type="button" id="default-sidebar" class="btn btn-outline-primary">Default Header</button>
	  </div>
	  
      <ul class="switcher">
        <li id="theme1"></li>
        <li id="theme2"></li>
        <li id="theme3"></li>
        <li id="theme4"></li>
        <li id="theme5"></li>
        <li id="theme6"></li>
      </ul>
      
     </div>
   </div>
-->
  <!--end color switcher-->
  
  </div><!--End wrapper-->
  <!-- Bootstrap core JavaScript-->
  <script src="js/jquery.min.js"></script>
  <!--<script src="js/jquery-ui.min.js"></script>-->
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js" integrity="sha256-T0Vest3yCU7pafRw9r+settMBX6JkKN06dqBnpQ8d30=" crossorigin="anonymous"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
	
 <!-- simplebar js -->
  <script src="plugins/simplebar/js/simplebar.js"></script>
  <!-- sidebar-menu js -->
  <script src="js/sidebar-menu.js"></script>
  <script src="plugins/metismenu/js/metisMenu.min.js"></script>
  <!-- loader scripts -->
  <script src="js/jquery.loading-indicator.js"></script>
  <!-- Custom scripts -->
  <script src="js/app-script.js"></script>
  
  <!-- Chart js -->
  
  <script src="plugins/Chart.js/Chart.min.js"></script>
  <!-- Vector map JavaScript -->
  <script src="plugins/vectormap/jquery-jvectormap-2.0.2.min.js"></script>
  <script src="plugins/vectormap/jquery-jvectormap-world-mill-en.js"></script>
  <!-- Easy Pie Chart JS -->
  <script src="plugins/jquery.easy-pie-chart/jquery.easypiechart.min.js"></script>
  <!-- Sparkline JS -->
  <script src="plugins/sparkline-charts/jquery.sparkline.min.js"></script>
  <script src="plugins/jquery-knob/excanvas.js"></script>
  <script src="plugins/jquery-knob/jquery.knob.js"></script>
    
    <script>
        $(function() {
            $(".knob").knob();
            $('#message').fadeOut(6000);
        });
    </script>
    <script src="plugins/fullcalendar/js/moment.js"></script>
  <script src="plugins/fullcalendar/js/fullcalendar.js"></script>
  
 <!--Data Tables js-->
<script src="plugins/bootstrap-datatable/js/jquery.dataTables.min.js"></script>
  <script src="plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js"></script>
  <script src="plugins/bootstrap-datatable/js/dataTables.buttons.min.js"></script>
  <script src="plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js"></script>
  <script src="plugins/bootstrap-datatable/js/jszip.min.js"></script>
  <script src="plugins/bootstrap-datatable/js/pdfmake.min.js"></script>
  <script src="plugins/bootstrap-datatable/js/vfs_fonts.js"></script>
  <script src="plugins/bootstrap-datatable/js/buttons.html5.min.js"></script>
  <script src="plugins/bootstrap-datatable/js/buttons.print.min.js"></script>
  <script src="plugins/bootstrap-datatable/js/buttons.colVis.min.js"></script>
  <script src="js/codice.fiscale.var.js"></script>
  <script src="js/signature_pad.js"></script>
    
  

