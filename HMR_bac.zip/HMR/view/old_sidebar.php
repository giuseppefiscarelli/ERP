<div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
     <div class="brand-logo">
      <a href="index.html">
       <img src="images/HONDA.png" style="width:200px;" class="logo-icon" alt="logo icon">
       
     </a>
   </div>
<!--
   <div class="user-details"> 
    <div class="media align-items-center user-pointer collapsed" data-toggle="collapse" data-target="#user-dropdown">
      <div class="avatar"><img class="mr-3 side-user-img" src="https://via.placeholder.com/110x110" alt="user avatar"></div>
       <div class="media-body">
       <h6 class="side-user-name">Mark Johnson</h6>
      </div>
       </div>
     <div id="user-dropdown" class="collapse">
      <ul class="user-setting-menu">
            <li><a href="javaScript:void();"><i class="icon-user"></i>  My Profile</a></li>
            <li><a href="javaScript:void();"><i class="icon-settings"></i> Setting</a></li>
      <li><a href="javaScript:void();"><i class="icon-power"></i> Logout</a></li>
      </ul>
     </div>
      </div>

-->
<ul class="sidebar-menu">







       
<!-- new app-->
<li id="li_1" class="active">
       <a href="homehmr.php" class="waves-effect">
         <i class="fa fa-home"></i>
         <span>
         Home
         </span>
         
       </a>
       
        
</li>


<!-- new app-->
<li id="li_5">
       <a href="#?smurfid=0020c3f8e2da4c03b8c842222da886ff1097475b2804e4ef42ae4d5809af3418&amp;m_cod_menu=5&amp;m_sequenza=999999&amp;" class="waves-effect">
         <i class="fa fa-users"></i>
         <span>
         CRM
         </span>
         <i class="fa fa-angle-left pull-right"></i>
       </a>
       
        <ul class="sidebar-submenu">

<!-- new app-->
<li id="li_10">
       <a href="hmranagr.pgm?smurfid=0020c3f8e2da4c03b8c842222da886ff1097475b2804e4ef42ae4d5809af3418&amp;m_cod_menu=10&amp;m_sequenza=999999&amp;" class="waves-effect">
         <i class="fa fa-user"></i>
         <span>
         Clienti
         </span>
         
       </a>
       
        
</li>
</ul>
</li>


<!-- new app-->
<li id="li_100">
       <a href="#?smurfid=0020c3f8e2da4c03b8c842222da886ff1097475b2804e4ef42ae4d5809af3418&amp;m_cod_menu=100&amp;m_sequenza=999999&amp;" class="waves-effect">
         <i class="fa fa-motorcycle"></i>
         <span>
         TestRide
         </span>
         <i class="fa fa-angle-left pull-right"></i>
       </a>
       
        <ul class="sidebar-submenu">

<!-- new app-->
<li id="li_110">
       <a href="hmrteride.pgm?smurfid=0020c3f8e2da4c03b8c842222da886ff1097475b2804e4ef42ae4d5809af3418&amp;m_cod_menu=110&amp;m_sequenza=999999&amp;" class="waves-effect">
         <i class="fa fa-bar-chart"></i>
         <span>
         Gestione TestRide
         </span>
         
       </a>
       
        
</li>


<!-- new app-->
<li id="li_115">
       <a href="hmrteride.pgm?smurfid=0020c3f8e2da4c03b8c842222da886ff1097475b2804e4ef42ae4d5809af3418&amp;m_cod_menu=115&amp;m_sequenza=999999&amp;task=beginadd" class="waves-effect">
         <i class="fa fa-motorcycle"></i>
         <span>
         Nuovo TestRide
         </span>
         
       </a>
       
        
</li>
</ul>
</li>


<!-- new app-->
<li id="li_200">
       <a href="#?smurfid=0020c3f8e2da4c03b8c842222da886ff1097475b2804e4ef42ae4d5809af3418&amp;m_cod_menu=200&amp;m_sequenza=999999&amp;" class="waves-effect">
         <i class="fa fa-handshake-o"></i>
         <span>
         Contratto / Preventivo
         </span>
         <i class="fa fa-angle-left pull-right"></i>
       </a>
       
        <ul class="sidebar-submenu">

<!-- new app-->
<li id="li_201">
       <a href="hmrcontr.pgm?smurfid=0020c3f8e2da4c03b8c842222da886ff1097475b2804e4ef42ae4d5809af3418&amp;m_cod_menu=201&amp;m_sequenza=999999&amp;" class="waves-effect">
         <i class="fa fa-bar-chart"></i>
         <span>
         Gestione Contratto / Preventivo
         </span>
         
       </a>
       
        
</li>


<!-- new app-->
<li id="li_210">
       <a href="hmrcontr.pgm?smurfid=0020c3f8e2da4c03b8c842222da886ff1097475b2804e4ef42ae4d5809af3418&amp;m_cod_menu=210&amp;m_sequenza=999999&amp;task=beginadd" class="waves-effect">
         <i class="fa fa-handshake-o"></i>
         <span>
         Nuovo contratto
         </span>
         
       </a>
       
        
</li>
</ul>
</li>


<!-- new app-->
<li id="li_400">
       <a href="#?smurfid=0020c3f8e2da4c03b8c842222da886ff1097475b2804e4ef42ae4d5809af3418&amp;m_cod_menu=400&amp;m_sequenza=999999&amp;" class="waves-effect">
         <i class="fa fa-industry"></i>
         <span>
         Gestione Veicoli
         </span>
         <i class="fa fa-angle-left pull-right"></i>
       </a>
       
        <ul class="sidebar-submenu">

<!-- new app-->
<li id="li_401">
       <a href="hmrveiusa.pgm?smurfid=0020c3f8e2da4c03b8c842222da886ff1097475b2804e4ef42ae4d5809af3418&amp;m_cod_menu=401&amp;m_sequenza=999999&amp;" class="waves-effect">
         <i class="fa fa-motorcycle"></i>
         <span>
         Veicoli Usati
         </span>
         
       </a>
       
        
</li>


<!-- new app-->
<li id="li_402">
       <a href="honveinw.pgm?smurfid=0020c3f8e2da4c03b8c842222da886ff1097475b2804e4ef42ae4d5809af3418&amp;m_cod_menu=402&amp;m_sequenza=999999&amp;" class="waves-effect">
         <i class="fa fa-motorcycle"></i>
         <span>
         Veicoli Nuovi
         </span>
         
       </a>
       
        
</li>


<!-- new app-->
<li id="li_410">
       <a href="hmrlistino.PGM?smurfid=0020c3f8e2da4c03b8c842222da886ff1097475b2804e4ef42ae4d5809af3418&amp;m_cod_menu=410&amp;m_sequenza=999999&amp;" class="waves-effect">
         <i class="fa fa-list"></i>
         <span>
         Listino
         </span>
         
       </a>
       
        
</li>


<!-- new app-->
<li id="li_415">
       <a href="hmrcatalog.pgm?smurfid=0020c3f8e2da4c03b8c842222da886ff1097475b2804e4ef42ae4d5809af3418&amp;m_cod_menu=415&amp;m_sequenza=999999&amp;" class="waves-effect">
         <i class="fa fa-table"></i>
         <span>
         Catalogo Honda
         </span>
         
       </a>
       
        
</li>
</ul>
</li>


<!-- new app-->
<li id="li_1000">
       <a href="#?smurfid=0020c3f8e2da4c03b8c842222da886ff1097475b2804e4ef42ae4d5809af3418&amp;m_cod_menu=1000&amp;m_sequenza=999999&amp;" class="waves-effect">
         <i class="fa fa-navicon"></i>
         <span>
         Gestione Tabelle
         </span>
         <i class="fa fa-angle-left pull-right"></i>
       </a>
       
        <ul class="sidebar-submenu">

<!-- new app-->
<li id="li_1010">
       <a href="tabfin111.pgm?smurfid=0020c3f8e2da4c03b8c842222da886ff1097475b2804e4ef42ae4d5809af3418&amp;m_cod_menu=1010&amp;m_sequenza=999999&amp;" class="waves-effect">
         <i class="fa fa-bank"></i>
         <span>
         Tabelle Finanziamenti
         </span>
         
       </a>
       
        
</li>


<!-- new app-->
<li id="li_1015">
       <a href="hmrtabcol.pgm?smurfid=0020c3f8e2da4c03b8c842222da886ff1097475b2804e4ef42ae4d5809af3418&amp;m_cod_menu=1015&amp;m_sequenza=999999&amp;" class="waves-effect">
         <i class="fa fa-paint-brush"></i>
         <span>
         Tabella Colori
         </span>
         
       </a>
       
        
</li>
</ul>
</li>
</ul>
   
   </div>