<!DOCTYPE html>
<html lang="en">
<head>
<link rel="manifest" href="manifest.json">

<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="application-name" content="hmr">
<meta name="apple-mobile-web-app-title" content="hmr">
<meta name="msapplication-starturl" content="https://portfolio.setec.cloud:20009/ERP/HMR/">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link rel="icon" href="images/hmrsmall.ico">
<link rel="apple-touch-icon" href="images/hmrsmall.ico">
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title>HMR - </title>
  <!--favicon-->
  <link rel="icon" href="images/favicon.ico" type="image/x-icon"/>
  <!-- Vector CSS -->
  <link href="plugins/vectormap/jquery-jvectormap-2.0.2.css" rel="stylesheet"/>
  <!-- simplebar CSS-->
  <link href="plugins/simplebar/css/simplebar.css" rel="stylesheet"/>
  <!-- Bootstrap core CSS-->
  <link href="css/bootstrap.min.css" rel="stylesheet"/>
  <link href="css/jquery-ui.min.css" rel="stylesheet"/>
  <!--Data Tables -->
  <link href="plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css">
  <link href="plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css">
  <!-- animate CSS-->
  <link href="css/animate.css" rel="stylesheet" type="text/css"/>
  <!-- Icons CSS-->
  <link href="css/icons.css" rel="stylesheet" type="text/css"/>
  <!-- Sidebar CSS-->
  <link href="css/sidebar-menu.css" rel="stylesheet"/>
  <!-- Custom Style-->
  <link href="css/app-style.css" rel="stylesheet"/>
  <!-- skins CSS-->
  <link href="css/skins.css" rel="stylesheet"/>
  <link href="plugins/fullcalendar/css/fullcalendar.css" rel="stylesheet">
  <link href="css/signature_pad.css" rel="stylesheet"/>
 
</head>

<body style="background-image: url(images/5.jpg);background-size:cover;background-attachment: fixed;">

   <!-- start loader 

   <div id="pageloader-overlay" class="visible incoming">
     <div class="loader-wrapper-outer">
       <div class="loader-wrapper-inner"><
         div class="loader"></div></div></div></div>
   <!-- end loader -->